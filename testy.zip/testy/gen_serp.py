#!/usr/bin/env python3
"""Czysta serpentyna (posadzona): laser idzie tam-i-z-powrotem, zakrety na
krawedziach, koty na trasie. Lustra wymazujemy -> L = liczba luster.
Opcjonalnie sciany (--walls p) i wiele laserow w pasmach (--lasers k).

Uzycie: gen_serp.py H W [--every N] [--lasers K] [--walls P] [--seed S]
  --every 1  : serpentyna co wiersz (gesta, duze L)
  --every 2  : co drugi wiersz
  --lasers K : K laserow, kazdy w swoim poziomym pasmie
  --walls P  : ulamek scian wrzuconych w wolne pola NIE na trasie
"""
import sys, random

DIRS = {"A": (-1, 0), "V": (1, 0), "<": (0, -1), ">": (0, 1)}
def refl(mt, dr, dc): return (-dc, -dr) if mt == "/" else (dc, dr)


def plant_band(g, r0, r1, W, every, mirrors):
    """Posadz serpentyne lasera '>' od (r0,0), wiersze r0..r1 co `every`."""
    H = len(g)
    sr, sc, d = r0, 0, ">"
    g[r0][0] = ">"
    dr, dc = DIRS[d]
    r, c = sr, sc + 1
    rows = list(range(r0, r1 + 1, every))
    for i, row in enumerate(rows):
        # zamiataj ten wiersz w kierunku dr,dc (poziomo)
        while 0 <= c < W and 0 <= r < H:
            g[r][c] = "O"
            nc = c + dc
            if not (0 <= nc < W):
                break
            c = nc
        # zakret w dol do nastepnego wiersza pasma (jesli jest)
        if i + 1 >= len(rows):
            break
        nrow = rows[i + 1]
        # lustro zakrecajace w dol na krawedzi (komorka c,r)
        # idziemy w prawo (dc=1): '\' -> dol; w lewo (dc=-1): '/' -> dol
        mt_down = "\\" if dc == 1 else "/"
        g[r][c] = mt_down; mirrors.append((r, c))
        # zejdz w dol do nrow
        rr = r + 1
        while rr < nrow:
            g[rr][c] = "."  # tor pionowy (pusty)
            rr += 1
        # lustro wprowadzajace w nowy wiersz, kierunek poziomy sie odwraca
        ndc = -dc
        mt_in = "/" if (dc == 1) else "\\"  # dol->lewo to '/', dol->prawo to '\'
        g[nrow][c] = mt_in; mirrors.append((nrow, c))
        r, dc = nrow, ndc
        c = c + dc


def lit_cats(g, H, W, srcs):
    lit = set(); B = W * H * 2
    for (sr, sc, d) in srcs:
        dr, dc = DIRS[d]; r, c = sr, sc; step = 0
        while 0 <= r < H and 0 <= c < W:
            ch = g[r][c]
            if ch == "#": break
            if ch == "O": lit.add((r, c))
            elif ch == "/": dr, dc = refl("/", dr, dc)
            elif ch == "\\": dr, dc = refl("\\", dr, dc)
            r += dr; c += dc; step += 1
            if step > B: break
    return lit


def main():
    H = int(sys.argv[1]); W = int(sys.argv[2])
    every = 2; K = 1; walls = 0.0; seed = 1
    a = sys.argv[3:]
    for i, x in enumerate(a):
        if x == "--every": every = int(a[i + 1])
        if x == "--lasers": K = int(a[i + 1])
        if x == "--walls": walls = float(a[i + 1])
        if x == "--seed": seed = int(a[i + 1])
    rng = random.Random(seed)
    g = [["." for _ in range(W)] for _ in range(H)]
    mirrors = []
    band = H // K
    srcs = []
    for k in range(K):
        r0 = k * band
        r1 = min(H - 1, (k + 1) * band - 2)  # zostaw wiersz na granice
        if every == 2 and (r1 - r0) % 2 == 1:
            r1 -= 1
        plant_band(g, r0, r1, W, every, mirrors)
        srcs.append((r0, 0, ">"))
    # opcjonalne sciany na wolnych polach (nie na torze)
    if walls > 0:
        for r in range(H):
            for c in range(W):
                if g[r][c] == "." and rng.random() < walls:
                    g[r][c] = "#"
    # zostaw tylko realnie oswietlone koty
    lit = lit_cats(g, H, W, srcs)
    for r in range(H):
        for c in range(W):
            if g[r][c] == "O" and (r, c) not in lit:
                g[r][c] = "."
    L = len(mirrors)
    for (r, c) in mirrors:
        if g[r][c] in "/\\":
            g[r][c] = "."
    cats = sum(row.count("O") for row in g)
    sys.stderr.write(f"H={H} W={W} L={L} cats={cats} lasers={K} every={every} walls={walls}\n")
    sys.stdout.write("\n".join([f"{W} {H} {L}"] + ["".join(x) for x in g]) + "\n")


if __name__ == "__main__":
    main()
