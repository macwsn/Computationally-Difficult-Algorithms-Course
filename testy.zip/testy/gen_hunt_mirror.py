#!/usr/bin/env python3
"""Hunt for hard Checkpoint D instances with DENSE, HEAVILY-REFLECTING mirror
fields and SHARED reflections, where the reference solver gets low coverage.

Method (feasibility by construction = "planted solution"):
  1. build mostly-open / lightly-walled terrain (0-20% walls)
  2. place MANY lasers (8-30)
  3. for each laser, trace its beam; with high turn probability place a mirror
     ('/' or '\\') and reflect; sometimes drop a cat 'O' on the path
  4. simulate ALL lasers together with the planted mirrors (judge bound W*H*2)
  5. keep only cats actually lit; erase mirrors; L = number of planted mirrors
Because the planted mirrors form a valid solution lighting >= the kept cats,
the instance is feasible within L.

To force SHARED reflections we let beams cross an already-mirrored field: when a
beam hits a cell that ALREADY holds a planted mirror, it reflects off it (reuse),
so a single mirror can sit on multiple beams. We bias mirror placement toward
cells near other mirrors to make dense clusters.

Then we run the reference solver and litcheck; instances with coverage < 0.5 are
saved to tests_chd/hunt/mirror_<seed>.in
"""
import os
import random
import subprocess
import sys
import time

DIRS = {"A": (-1, 0), "V": (1, 0), "<": (0, -1), ">": (0, 1)}
ROOT = os.path.dirname(os.path.abspath(__file__))
HUNT = os.path.join(ROOT, "hunt")
SOLVER = "/tmp/sol8ref"
LITCHECK = os.path.join(ROOT, "litcheck.py")


def refl(mt, dr, dc):
    return (-dc, -dr) if mt == "/" else (dc, dr)


def lit_cats(g, H, W, srcs):
    """Judge-consistent simulation, step bound = W*H*2."""
    lit = set()
    B = W * H * 2
    for (sr, sc, d) in srcs:
        dr, dc = DIRS[d]
        r, c = sr, sc
        step = 0
        while True:
            if not (0 <= r < H and 0 <= c < W):
                break
            ch = g[r][c]
            if ch == "#":
                break
            if ch == "O":
                lit.add((r, c))
            elif ch == "/":
                dr, dc = refl("/", dr, dc)
            elif ch == "\\":
                dr, dc = refl("\\", dr, dc)
            r += dr
            c += dc
            step += 1
            if step > B:
                break
    return lit


def used_mirrors_to_cats(g, H, W, srcs, mirror_cells, cat_cells):
    """Return the subset of planted mirror cells that lie on a beam segment
    BEFORE the beam reaches a lit cat. Prunes mirrors that only appear after the
    last cat on a beam (dead tail), shrinking L toward the truly-needed set."""
    used = set()
    B = W * H * 2
    catset = set(cat_cells)
    for (sr, sc, d) in srcs:
        dr, dc = DIRS[d]
        r, c = sr, sc
        step = 0
        seg_mirrors = []      # mirrors hit since start
        while True:
            if not (0 <= r < H and 0 <= c < W):
                break
            ch = g[r][c]
            if ch == "#":
                break
            if (r, c) in catset:
                # everything bounced so far is needed to reach this cat
                used.update(seg_mirrors)
            if ch == "/":
                if (r, c) in mirror_cells:
                    seg_mirrors.append((r, c))
                dr, dc = refl("/", dr, dc)
            elif ch == "\\":
                if (r, c) in mirror_cells:
                    seg_mirrors.append((r, c))
                dr, dc = refl("\\", dr, dc)
            r += dr
            c += dc
            step += 1
            if step > B:
                break
    return used


def terrain(H, W, wall_p, rng):
    g = [["#" if rng.random() < wall_p else "." for _ in range(W)] for _ in range(H)]
    return g


def gen(seed, H, W, n_lasers, turn_p, cat_p, wall_p, maxm_frac):
    rng = random.Random(seed)
    g = terrain(H, W, wall_p, rng)
    placed = set()           # cells holding a planted mirror
    placed_list = []
    srcs = []
    B = W * H * 2
    maxm = int(H * W * maxm_frac)

    def free_cells():
        return [(r, c) for r in range(H) for c in range(W) if g[r][c] == "."]

    fl = free_cells()
    if len(fl) < n_lasers + 10:
        return None
    rng.shuffle(fl)
    laser_cells = fl[:n_lasers]

    # place lasers
    for (sr, sc) in laser_cells:
        d = rng.choice("AV<>")
        g[sr][sc] = d
        srcs.append((sr, sc, d))

    # trace each laser, planting mirrors/cats along the way
    for (sr, sc, d) in srcs:
        dr, dc = DIRS[d]
        r, c = sr + dr, sc + dc
        step = 0
        while step < B:
            if not (0 <= r < H and 0 <= c < W):
                break
            ch = g[r][c]
            if ch == "#":
                break
            if ch in "AV<>":
                # passes laser cells (judge: laser cells transparent)
                r += dr; c += dc; step += 1
                continue
            if ch in "/\\":
                # SHARED reflection: reuse an existing planted mirror
                dr, dc = refl(ch, dr, dc)
                r += dr; c += dc; step += 1
                continue
            if ch == "O":
                r += dr; c += dc; step += 1
                continue
            # empty cell: maybe plant a mirror (turn) or a cat
            roll = rng.random()
            # bias turn probability up if a neighbor already has a mirror
            nbr_mirror = any(
                (0 <= r + ar < H and 0 <= c + ac < W and (r + ar, c + ac) in placed)
                for ar, ac in ((-1, 0), (1, 0), (0, -1), (0, 1))
            )
            eff_turn = turn_p + (0.15 if nbr_mirror else 0.0)
            if roll < eff_turn and len(placed) < maxm:
                mt = rng.choice("/\\")
                g[r][c] = mt
                placed.add((r, c))
                placed_list.append((r, c))
                dr, dc = refl(mt, dr, dc)
            elif roll < eff_turn + cat_p:
                g[r][c] = "O"
            r += dr; c += dc; step += 1

    if len(placed) < 1:
        return None

    lit = lit_cats(g, H, W, srcs)
    # drop unlit cats
    for r in range(H):
        for c in range(W):
            if g[r][c] == "O" and (r, c) not in lit:
                g[r][c] = "."
    if len(lit) < 3:
        return None

    # PRUNE dead-tail mirrors: keep only mirrors needed to reach a lit cat.
    used = used_mirrors_to_cats(g, H, W, srcs, placed, lit)
    # remove unused planted mirrors from grid (turn them back to '.')
    for (r, c) in placed_list:
        if (r, c) not in used:
            g[r][c] = "."
    # re-simulate with pruned mirror field; some cats may now go dark
    lit2 = lit_cats(g, H, W, srcs)
    for r in range(H):
        for c in range(W):
            if g[r][c] == "O" and (r, c) not in lit2:
                g[r][c] = "."
    if len(lit2) < 3:
        return None
    # the planted (pruned) mirror field is a valid solution -> L = #used mirrors
    L = len(used)
    if L < 1:
        return None

    # erase the (used) mirrors -> the actual puzzle
    for (r, c) in used:
        g[r][c] = "."

    text = "\n".join([f"{W} {H} {L}"] + ["".join(x) for x in g]) + "\n"
    meta = dict(W=W, H=H, L=L, cats=len(lit2), lasers=len(srcs),
                density=L / (H * W))
    return text, meta


def gen_shared_serp(seed, H, W, n_lasers, row_step, cat_density):
    """Multiple serpentines that SHARE turn mirrors. Each serpentine is a laser
    snaking across rows; turn mirrors live in shared "gutter" columns so beams
    from different lasers reuse the same mirror cells (shared reflections). Cats
    sit DEEP along the snake, so reaching them needs the whole bounce chain.
    L is set TIGHT to the count of distinct used mirror cells.
    """
    rng = random.Random(seed)
    g = [["." for _ in range(W)] for _ in range(H)]
    placed = set()
    placed_list = []
    srcs = []

    # lasers enter from the left edge interior at staggered rows, all going right
    start_rows = sorted(set(rng.sample(range(1, H - 1), min(n_lasers, H - 2))))
    for sr in start_rows:
        if g[sr][0] != ".":
            continue
        g[sr][0] = ">"
        srcs.append((sr, 0, ">"))
        # snake this beam
        cur_row = sr
        going_right = True
        col = 1
        guard = 0
        while 0 <= cur_row < H and guard < H * 4:
            guard += 1
            cols = range(1, W) if going_right else range(W - 2, -1, -1)
            for cc in cols:
                if g[cur_row][cc] == "." and rng.random() < cat_density:
                    g[cur_row][cc] = "O"
            end_c = W - 1 if going_right else 0
            nxt = cur_row + row_step
            if nxt >= H - 1:
                break
            # place / reuse turn mirrors at the two gutter cells
            def put(rr, cc, mt):
                ch = g[rr][cc]
                if ch in "/\\":
                    return  # shared: reuse whatever is there (may differ; ok)
                if ch == "O":
                    return
                g[rr][cc] = mt
                if (rr, cc) not in placed:
                    placed.add((rr, cc)); placed_list.append((rr, cc))
            if going_right:
                put(cur_row, end_c, "\\")
                put(nxt, end_c, "/")
            else:
                put(cur_row, end_c, "/")
                put(nxt, end_c, "\\")
            going_right = not going_right
            cur_row = nxt

    if len(placed) < 1:
        return None
    lit = lit_cats(g, H, W, srcs)
    for r in range(H):
        for c in range(W):
            if g[r][c] == "O" and (r, c) not in lit:
                g[r][c] = "."
    if len(lit) < 3:
        return None
    used = used_mirrors_to_cats(g, H, W, srcs, placed, lit)
    for (r, c) in placed_list:
        if (r, c) not in used:
            g[r][c] = "."
    lit2 = lit_cats(g, H, W, srcs)
    for r in range(H):
        for c in range(W):
            if g[r][c] == "O" and (r, c) not in lit2:
                g[r][c] = "."
    if len(lit2) < 3:
        return None
    L = len(used)
    if L < 1:
        return None
    for (r, c) in used:
        g[r][c] = "."
    text = "\n".join([f"{W} {H} {L}"] + ["".join(x) for x in g]) + "\n"
    meta = dict(W=W, H=H, L=L, cats=len(lit2), lasers=len(srcs),
                density=L / (H * W))
    return text, meta


def gen_tiled_serp(seed, H, W, block_h, block_w, row_step, cat_p, descent_cat_p):
    """Tile the board with independent serpentine TRAP blocks, each with its own
    laser. Within a block the beam snakes row-by-row; turning back at row ends
    momentarily *reduces* coverage (cuts a long straight ray), which a
    coverage-greedy beam search resists -> documented pathology. Many blocks =
    many simultaneous traps; if the solver botches the turn-back in most blocks
    its TOTAL coverage falls below 0.5. L is tight (= used turn mirrors)."""
    rng = random.Random(seed)
    g = [["." for _ in range(W)] for _ in range(H)]
    placed = set(); placed_list = []
    srcs = []

    def put(rr, cc, mt):
        if not (0 <= rr < H and 0 <= cc < W):
            return
        if g[rr][cc] in "/\\O" or g[rr][cc] in "AV<>":
            return
        g[rr][cc] = mt
        if (rr, cc) not in placed:
            placed.add((rr, cc)); placed_list.append((rr, cc))

    for br in range(0, H - block_h + 1, block_h):
        for bc in range(0, W - block_w + 1, block_w):
            r0, c0 = br, bc
            r1, c1 = br + block_h - 1, bc + block_w - 1
            # laser at top-left of block, going right
            if g[r0][c0] != ".":
                continue
            g[r0][c0] = ">"
            srcs.append((r0, c0, ">"))
            cur_row = r0
            going_right = True
            while cur_row < r1:
                cols = range(c0 + 1, c1 + 1) if going_right else range(c1 - 1, c0 - 1, -1)
                for cc in cols:
                    if g[cur_row][cc] == "." and rng.random() < cat_p:
                        g[cur_row][cc] = "O"
                end_c = c1 if going_right else c0
                nxt = cur_row + row_step
                if nxt > r1:
                    break
                for rr in range(cur_row + 1, nxt):
                    if g[rr][end_c] == "." and rng.random() < descent_cat_p:
                        g[rr][end_c] = "O"
                if going_right:
                    put(cur_row, end_c, "\\"); put(nxt, end_c, "/")
                else:
                    put(cur_row, end_c, "/"); put(nxt, end_c, "\\")
                going_right = not going_right
                cur_row = nxt

    if len(placed) < 1:
        return None
    lit = lit_cats(g, H, W, srcs)
    for r in range(H):
        for c in range(W):
            if g[r][c] == "O" and (r, c) not in lit:
                g[r][c] = "."
    if len(lit) < 3:
        return None
    used = used_mirrors_to_cats(g, H, W, srcs, placed, lit)
    for (r, c) in placed_list:
        if (r, c) not in used:
            g[r][c] = "."
    lit2 = lit_cats(g, H, W, srcs)
    for r in range(H):
        for c in range(W):
            if g[r][c] == "O" and (r, c) not in lit2:
                g[r][c] = "."
    if len(lit2) < 3:
        return None
    L = len(used)
    if L < 1:
        return None
    for (r, c) in used:
        g[r][c] = "."
    text = "\n".join([f"{W} {H} {L}"] + ["".join(x) for x in g]) + "\n"
    meta = dict(W=W, H=H, L=L, cats=len(lit2), lasers=len(srcs),
                density=L / (H * W))
    return text, meta


def run_solver(text, timeout_s):
    try:
        p = subprocess.run([SOLVER], input=text, capture_output=True,
                           text=True, timeout=timeout_s)
        return p.stdout
    except subprocess.TimeoutExpired:
        return None
    except Exception:
        return None


def coverage(in_path, out_path):
    try:
        p = subprocess.run(["uv", "run", "python", LITCHECK, in_path, out_path],
                           capture_output=True, text=True, timeout=30)
        line = p.stdout.strip().split("\n")[0]
        frac = line.split()[0]  # "lit/total"
        a, b = frac.split("/")
        a, b = int(a), int(b)
        return (a / b if b else 1.0), line
    except Exception as e:
        return None, str(e)


def build_instance(seed):
    """Pick a structural family + parameters from the seed and build an
    instance. Returns (text, meta) or None. Families ranked by observed
    hardness: forced dense serpentine (rs=1, tight L) is strongest, so it is
    sampled most often."""
    rng = random.Random(seed * 7919 + 13)
    fam = rng.choices(
        ["serp1", "serp_tiled", "serp_shared", "dense_cross"],
        weights=[0.50, 0.25, 0.15, 0.10])[0]
    sizes = [(80, 80), (90, 90), (100, 100), (100, 80), (60, 100), (100, 60)]
    H, W = rng.choice(sizes)

    if fam == "serp1":
        # one full-board snake, rs=1, dense in-row cats, very tight L
        cat_p = rng.uniform(0.10, 0.45)
        return gen_tiled_serp(seed, H, W, H, W, 1, cat_p, 0.0)
    if fam == "serp_tiled":
        # several full-width bands, each a rs=1 snake -> multiple turn-back traps
        bh = rng.choice([20, 25, 33, 50])
        cat_p = rng.uniform(0.08, 0.30)
        dcp = rng.uniform(0.0, 0.2)
        return gen_tiled_serp(seed, H, W, bh, W, 1, cat_p, dcp)
    if fam == "serp_shared":
        n_lasers = rng.randint(8, 25)
        row_step = rng.choice([1, 2])
        cat_density = rng.uniform(0.03, 0.10)
        return gen_shared_serp(seed, H, W, n_lasers, row_step, cat_density)
    # dense_cross: many lasers, dense shared mirrors, tight cap
    n_lasers = rng.randint(12, 28)
    turn_p = rng.uniform(0.35, 0.6)
    cat_p = rng.uniform(0.03, 0.08)
    return gen(seed, H, W, n_lasers, turn_p, cat_p, 0.0,
               rng.uniform(0.02, 0.06))


def main():
    os.makedirs(HUNT, exist_ok=True)
    seeds_budget = int(sys.argv[1]) if len(sys.argv) > 1 else 400
    time_budget = float(sys.argv[2]) if len(sys.argv) > 2 else 240.0
    sol_timeout = 12.0
    start = time.time()

    saved = []
    all_cov = []
    lowest = (2.0, None, None, None)   # (cov, seed, meta, line)
    tmp_in = "/tmp/_hunt_in.txt"
    tmp_out = "/tmp/_hunt_out.txt"

    n_attempts = 0
    for seed in range(seeds_budget):
        if time.time() - start > time_budget:
            break
        res = build_instance(seed)
        if res is None:
            continue
        text, meta = res
        if meta["cats"] < 3 or meta["lasers"] < 1:
            continue
        n_attempts += 1

        if time.time() - start > time_budget:
            break

        with open(tmp_in, "w") as f:
            f.write(text)
        out = run_solver(text, sol_timeout)
        if out is None:
            # solver timed out -> feasible by construction, judge would give 0
            # within the limit -> effectively a breaking case.
            fn = os.path.join(HUNT, f"mirror_{seed}.in")
            with open(fn, "w") as f:
                f.write(text)
            saved.append((fn, meta, "TLE", 0.0))
            all_cov.append(0.0)
            lowest = (0.0, seed, meta, "TLE")
            continue
        with open(tmp_out, "w") as f:
            f.write(out)
        cov, line = coverage(tmp_in, tmp_out)
        if cov is None:
            continue
        all_cov.append(cov)
        if cov < lowest[0]:
            lowest = (cov, seed, meta, line)
        if cov < 0.5:
            fn = os.path.join(HUNT, f"mirror_{seed}.in")
            with open(fn, "w") as f:
                f.write(text)
            saved.append((fn, meta, line, cov))

    # report
    print(f"attempts_with_valid_instance={n_attempts}")
    print(f"measured_coverages={len(all_cov)}")
    if all_cov:
        sc = sorted(all_cov)
        print(f"coverage_min={sc[0]:.3f} median={sc[len(sc)//2]:.3f} max={sc[-1]:.3f}")
    if lowest[1] is not None:
        lc, ls, lm, ll = lowest
        print(f"LOWEST: seed={ls} {lm['W']}x{lm['H']} L={lm['L']} cats={lm['cats']} "
              f"lasers={lm['lasers']} dens={lm['density']:.3f} cov={lc:.3f} [{ll}]")
    print(f"SAVED(<0.5)={len(saved)}")
    for fn, meta, line, cov in saved:
        print(f"  {os.path.basename(fn)}: W={meta['W']} H={meta['H']} L={meta['L']} "
              f"cats={meta['cats']} lasers={meta['lasers']} dens={meta['density']:.3f} "
              f"cov={cov:.3f} [{line}]")


if __name__ == "__main__":
    main()
