#!/usr/bin/env python3
"""Feasibility checker. Reads an .in board plus a planted-mirror file and
verifies the planted mirror layout lights ALL cats (judge raytrace).

Usage: feascheck.py in.txt mirrors.txt
  mirrors.txt: lines "r c m" where m is / or \\ (0-indexed row,col)
Prints "X/Y SOLVED|partial" and "L_used=k".
"""
import sys

DZ = {"A": (0, -1), "V": (0, 1), "<": (-1, 0), ">": (1, 0)}


def trace(b, x, y, dx, dy, bnd):
    H, W = len(b), len(b[0])
    s = 0
    while 0 <= y < H and 0 <= x < W:
        ch = b[y][x]
        if ch == "O":
            b[y][x] = "X"
        if ch == "#":
            break
        if ch == "/":
            dx, dy = -dy, -dx
        if ch == "\\":
            dx, dy = dy, dx
        x += dx
        y += dy
        s += 1
        if s > bnd:
            return


def load(fn):
    f = open(fn)
    W, H, M = map(int, f.readline().split())
    b = [list(f.readline().rstrip("\n")) for _ in range(H)]
    return b, W, H, M


ib, W, H, M = load(sys.argv[1])
B = W * H * 2
tot = sum(r.count("O") for r in ib)
nsrc = sum(r.count("A") + r.count("V") + r.count("<") + r.count(">") for r in ib)
assert nsrc >= 1, "board has no laser source"
# place planted mirrors
used = 0
for line in open(sys.argv[2]):
    line = line.strip()
    if not line:
        continue
    r, c, m = line.split()
    r, c = int(r), int(c)
    assert ib[r][c] == ".", f"planted mirror on non-empty cell {r},{c}={ib[r][c]}"
    ib[r][c] = m
    used += 1
for y in range(H):
    for x in range(W):
        if ib[y][x] in DZ:
            trace(ib, x, y, DZ[ib[y][x]][0], DZ[ib[y][x]][1], B)
lit = tot - sum(r.count("O") for r in ib)
print(f"{lit}/{tot}", "SOLVED" if lit == tot else "partial", f"L_used={used} L_budget={M}")
