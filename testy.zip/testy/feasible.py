import sys, os, glob
from collections import deque

DD = {"A": 0, ">": 1, "V": 2, "<": 3}
DR = [-1, 0, 1, 0]
DC = [0, 1, 0, -1]

def check(path):
    t = open(path).read().split("\n")
    if not t[0].strip():
        return "EMPTYFILE", []
    W, H, M = map(int, t[0].split())
    g = [t[1 + i].ljust(W, '.')[:W] for i in range(H)]
    lasers = [(r, c, DD[g[r][c]]) for r in range(H) for c in range(W) if g[r][c] in DD]
    cats = [(r, c) for r in range(H) for c in range(W) if g[r][c] == 'O']
    if not cats:
        return "NOCATS", []
    if not lasers:
        return "NOLASER", cats
    # free-turn beam reachability over (cell, dir): straight always; turn at '.' cells
    seen = [[False] * 4 for _ in range(W * H)]
    dq = deque()
    for (r, c, d) in lasers:
        rr, cc = r + DR[d], c + DC[d]
        if 0 <= rr < H and 0 <= cc < W and g[rr][cc] != '#' and not seen[rr * W + cc][d]:
            seen[rr * W + cc][d] = True
            dq.append((rr, cc, d))
    covered = [[False] * W for _ in range(H)]
    while dq:
        r, c, d = dq.popleft()
        covered[r][c] = True
        ch = g[r][c]
        dirs = [d]
        if ch == '.':
            dirs += [(d + 1) & 3, (d + 3) & 3]
        for nd in dirs:
            rr, cc = r + DR[nd], c + DC[nd]
            if 0 <= rr < H and 0 <= cc < W and g[rr][cc] != '#' and not seen[rr * W + cc][nd]:
                seen[rr * W + cc][nd] = True
                dq.append((rr, cc, nd))
    bad = [(r, c) for (r, c) in cats if not covered[r][c]]
    return ("OK" if not bad else "UNREACHABLE"), bad

dirs = ["cases", "hard", "big100", "big", "profile", "tight", "wallhunt", "multihunt", "windhunt", "hunt"]
os.makedirs("infeasible", exist_ok=True)
moved = 0
for d in dirs:
    for f in sorted(glob.glob(os.path.join(d, "*.in"))):
        st, bad = check(f)
        if st != "OK":
            print(f"{st:12s} {f}  badcats={len(bad)} {bad[:4]}")
            os.rename(f, os.path.join("infeasible", d + "__" + os.path.basename(f)))
            moved += 1
print(f"moved {moved} provably-impossible boards to infeasible/")
