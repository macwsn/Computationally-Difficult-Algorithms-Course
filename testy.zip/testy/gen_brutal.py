#!/usr/bin/env python3
"""Generate VERY hard 100x100 wall-heavy instances (lots of blockades, complex
winding structure). Feasibility guaranteed by plant-and-erase: walk each beam
through the labyrinth planting turn-mirrors + cats; that mirror layout IS a valid
solution; keep only truly-lit cats, erase mirrors, set L = #planted mirrors.

Terrain modes (all wall-heavy 100x100):
  maze     - recursive-backtracker perfect maze (~50% walls, 1-wide passages)
  braid    - maze with some dead-end walls knocked out -> loops (routing choices)
  rooms    - grid of rooms joined by narrow doors, walls between
  cavemaze - cellular-automata cave overlaid on a carved maze (very irregular)

Run:  python gen_brutal.py
Outputs tests_chd/brutal/brutal_<i>.in and prints stats.
"""
import os, random

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(HERE, "brutal")
BS = "\\"
DIRS = {"A": (-1, 0), "V": (1, 0), "<": (0, -1), ">": (0, 1)}


def refl(mt, dr, dc):
    return (-dc, -dr) if mt == "/" else (dc, dr)


def mirror_for_turn(dr, dc, ndr, ndc):
    for mt in ("/", BS):
        if refl(mt, dr, dc) == (ndr, ndc):
            return mt
    return None


def lit_cats(g, H, W, srcs):
    lit = set()
    B = W * H * 2
    for (sr, sc, d) in srcs:
        dr, dc = DIRS[d]
        r, c = sr, sc
        step = 0
        while 0 <= r < H and 0 <= c < W:
            ch = g[r][c]
            if ch == "#":
                break
            if ch == "O":
                lit.add((r, c))
            elif ch == "/":
                dr, dc = refl("/", dr, dc)
            elif ch == BS:
                dr, dc = refl(BS, dr, dc)
            r += dr; c += dc; step += 1
            if step > B:
                break
    return lit


def carve_maze(H, W, rng):
    g = [["#"] * W for _ in range(H)]
    def carve(r, c):
        stack = [(r, c)]; g[r][c] = "."
        while stack:
            r, c = stack[-1]
            dirs = [(-2, 0), (2, 0), (0, -2), (0, 2)]; rng.shuffle(dirs)
            adv = False
            for dr, dc in dirs:
                nr, nc = r + dr, c + dc
                if 0 < nr < H and 0 < nc < W and g[nr][nc] == "#":
                    g[r + dr // 2][c + dc // 2] = "."; g[nr][nc] = "."
                    stack.append((nr, nc)); adv = True; break
            if not adv:
                stack.pop()
    carve(1, 1)
    return g


def terrain(mode, H, W, rng):
    if mode == "maze":
        return carve_maze(H, W, rng)
    if mode == "braid":
        g = carve_maze(H, W, rng)
        # knock out ~12% of interior walls -> loops & routing choices
        for r in range(1, H - 1):
            for c in range(1, W - 1):
                if g[r][c] == "#" and rng.random() < 0.12:
                    g[r][c] = "."
        return g
    if mode == "rooms":
        g = [["#"] * W for _ in range(H)]
        rs = rng.choice([10, 12, 14])           # room cell size
        for r0 in range(1, H, rs):
            for c0 in range(1, W, rs):
                r1, c1 = min(H - 1, r0 + rs - 2), min(W - 1, c0 + rs - 2)
                for r in range(r0, r1):
                    for c in range(c0, c1):
                        g[r][c] = "."
                # doors to right and down neighbour rooms
                if c1 + 1 < W - 1:
                    dr = rng.randint(r0, r1 - 1); g[dr][c1] = "."; g[dr][c1 + 1] = "."
                if r1 + 1 < H - 1:
                    dc = rng.randint(c0, c1 - 1); g[r1][dc] = "."; g[r1 + 1][dc] = "."
        return g
    # cavemaze: CA cave intersected with a carved maze -> irregular wall-heavy
    fill = 0.46
    cv = [["#" if rng.random() < fill else "." for _ in range(W)] for _ in range(H)]
    for _ in range(4):
        ng = [row[:] for row in cv]
        for r in range(H):
            for c in range(W):
                w = sum(cv[(r + dr) % H][(c + dc) % W] == "#"
                        for dr in (-1, 0, 1) for dc in (-1, 0, 1))
                ng[r][c] = "#" if w >= 5 else "."
        cv = ng
    mz = carve_maze(H, W, rng)
    return [["." if (cv[r][c] == "." and mz[r][c] == ".") else "#"
             for c in range(W)] for r in range(H)]


def gen(seed, mode, H, W, nsrc, mirror_p, cat_p):
    rng = random.Random(seed)
    g = terrain(mode, H, W, rng)
    placed = []; total_m = 0; srcs = []
    B = W * H * 2
    maxm = max(H, W) * 6

    def free():
        return [(r, c) for r in range(H) for c in range(W) if g[r][c] == "."]

    def is_open(r, c):
        return 0 <= r < H and 0 <= c < W and g[r][c] == "."

    if len(free()) < 40:
        return None
    for _ in range(nsrc):
        fl = free()
        if not fl:
            break
        sr, sc = rng.choice(fl)
        d = rng.choice("AV<>")
        dr, dc = DIRS[d]
        g[sr][sc] = d; srcs.append((sr, sc, d))
        r, c = sr + dr, sc + dc; step = 0
        while step < B:
            if not (0 <= r < H and 0 <= c < W) or g[r][c] == "#":
                break
            if g[r][c] == ".":
                ahead = is_open(r + dr, c + dc)
                perp = []
                for ndr, ndc in ((-1, 0), (1, 0), (0, -1), (0, 1)):
                    if (ndr, ndc) in ((dr, dc), (-dr, -dc)):
                        continue
                    if is_open(r + ndr, c + ndc):
                        mt = mirror_for_turn(dr, dc, ndr, ndc)
                        if mt:
                            perp.append((ndr, ndc, mt))
                roll = rng.random()
                must = (not ahead) and perp
                want = perp and roll < mirror_p
                if (must or want) and total_m < maxm:
                    ndr, ndc, mt = rng.choice(perp)
                    g[r][c] = mt; placed.append((r, c)); total_m += 1
                    dr, dc = ndr, ndc
                elif roll < mirror_p + cat_p:
                    g[r][c] = "O"
            r += dr; c += dc; step += 1

    if total_m < 5:
        return None
    lit = lit_cats(g, H, W, srcs)
    for r in range(H):
        for c in range(W):
            if g[r][c] == "O" and (r, c) not in lit:
                g[r][c] = "."
    cats = len(lit)
    if cats < 20 or len(srcs) < 1:
        return None
    assert lit == lit_cats(g, H, W, srcs), "planted solution must light all kept cats"
    for (r, c) in placed:
        g[r][c] = "."
    L = total_m
    board = "\n".join([f"{W} {H} {L}"] + ["".join(x) for x in g]) + "\n"
    walls = sum(row.count("#") for row in g)
    return board, cats, len(srcs), L, walls


def main():
    os.makedirs(OUT, exist_ok=True)
    H = W = 100
    configs = [
        ("maze",     8,  0.55, 0.40),
        ("maze",     10, 0.62, 0.45),
        ("braid",    9,  0.55, 0.42),
        ("braid",    11, 0.60, 0.48),
        ("rooms",    10, 0.45, 0.40),
        ("rooms",    12, 0.50, 0.45),
        ("cavemaze", 8,  0.55, 0.42),
        ("cavemaze", 10, 0.60, 0.48),
    ]
    print(f"{'file':22s} {'mode':9s} {'walls%':>6s} {'cats':>6s} {'L':>5s} {'lasers':>6s}")
    made = 0
    for i, (mode, nsrc, mp, cp) in enumerate(configs):
        out = None
        for seed in range(i * 1000, i * 1000 + 400):   # retry seeds until a valid hard board
            out = gen(seed, mode, H, W, nsrc, mp, cp)
            if out:
                board, cats, las, L, walls = out
                if cats >= 60 and walls >= 0.25 * W * H:   # demand many cats + heavy walls
                    break
                out = None
        if not out:
            print(f"brutal_{i:<2d}            FAILED to find hard board for {mode}")
            continue
        board, cats, las, L, walls = out
        fn = os.path.join(OUT, f"brutal_{i}.in")
        open(fn, "w", newline="\n").write(board)
        made += 1
        print(f"brutal_{i}.in{'':10s} {mode:9s} {100*walls//(W*H):>5d}% {cats:>6d} {L:>5d} {las:>6d}")
    print(f"\nwrote {made} boards to {OUT}")


if __name__ == "__main__":
    main()
