#!/usr/bin/env python3
"""Hunt generator: FEW cats, each buried behind a LONG, UNIQUE, multi-turn route.

Angle (unexplored): deep wall-pockets / spiral corridors. We do NOT scatter
cats or build regular structure. Instead, for each cat we carve a private
winding corridor from a laser, plant the mirrors that thread the beam to the
end of that corridor (where the cat sits), then erase mirrors so the solver
must rediscover the long route under a tight budget L = #planted mirrors (+slack).

Feasibility is GUARANTEED by construction: the planted mirrors form a valid
solution; we simulate (judge bound W*H*2), keep only genuinely lit cats, and
re-verify the planted solution lights every kept cat before saving.

Usage:
    gen_hunt_pocket.py            # run the full hunt (writes breaking cases)
    gen_hunt_pocket.py --one SEED # emit one board to stdout (for debugging)
"""
import os
import random
import subprocess
import sys

DIRS = {"A": (-1, 0), "V": (1, 0), "<": (0, -1), ">": (0, 1)}
PROJ = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SOLVER = "/tmp/sol8ref"


def refl(mt, dr, dc):
    return (-dc, -dr) if mt == "/" else (dc, dr)


def lit_cats(g, H, W, srcs):
    """Judge-faithful simulation, bound W*H*2 steps per laser."""
    lit = set()
    B = W * H * 2
    for (sr, sc, d) in srcs:
        dr, dc = DIRS[d]
        r, c = sr, sc
        step = 0
        while True:
            if not (0 <= r < H and 0 <= c < W):
                break
            ch = g[r][c]
            if ch == "#":
                break
            if ch == "O":
                lit.add((r, c))
            elif ch == "/":
                dr, dc = refl("/", dr, dc)
            elif ch == "\\":
                dr, dc = refl("\\", dr, dc)
            r += dr
            c += dc
            step += 1
            if step > B:
                break
    return lit


# ---------------------------------------------------------------------------
# Corridor planting: a beam walking a sequence of straight runs joined by turns.
# At each turn we place the mirror that converts the incoming dir to the
# desired outgoing dir. A cat is dropped at the far end of the route.
# ---------------------------------------------------------------------------

# For a given incoming (dr,dc) and desired outgoing (ndr,ndc), which mirror?
def mirror_for(dr, dc, ndr, ndc):
    if refl("/", dr, dc) == (ndr, ndc):
        return "/"
    if refl("\\", dr, dc) == (ndr, ndc):
        return "\\"
    return None  # not a 90-degree turn reachable by a single mirror


TURNS = {  # for each direction, the two perpendicular directions
    (-1, 0): [(0, -1), (0, 1)],
    (1, 0): [(0, -1), (0, 1)],
    (0, -1): [(-1, 0), (1, 0)],
    (0, 1): [(-1, 0), (1, 0)],
}


def plant_one_route(g, H, W, rng, n_turns, seg_min, seg_max, max_tries=60):
    """Carve a single winding corridor through '#'/'.' terrain.

    Returns (laser_cell, laser_dir, mirror_cells, cat_cell) on success, else None.
    The route only uses cells that are currently '#' (we carve them to '.').
    The beam cells along straight runs become '.', turn cells become mirrors,
    the final cell becomes the cat. Walls around the corridor stay '#'.
    """
    for _ in range(max_tries):
        # start at a random interior cell, pick a random initial direction
        sr = rng.randrange(1, H - 1)
        sc = rng.randrange(1, W - 1)
        d = rng.choice("AV<>")
        dr, dc = DIRS[d]
        path = []          # list of (r,c) corridor cells (excluding laser cell)
        turns = []         # list of (r,c, mirror) turn cells
        r, c = sr, sc
        occ = {(sr, sc)}   # cells used by this route (laser included)
        ok = True
        nseg = n_turns + 1
        for seg in range(nseg):
            seglen = rng.randint(seg_min, seg_max)
            # walk straight seglen cells in (dr,dc)
            advanced = 0
            for _step in range(seglen):
                nr, nc = r + dr, c + dc
                # need room; keep a 0-border (cells must be 1..H-2 / 1..W-2)
                if not (1 <= nr <= H - 2 and 1 <= nc <= W - 2):
                    ok = False
                    break
                if (nr, nc) in occ:
                    ok = False
                    break
                r, c = nr, nc
                occ.add((r, c))
                path.append((r, c))
                advanced += 1
            if not ok or advanced == 0:
                ok = False
                break
            if seg < nseg - 1:
                # turn: choose a perpendicular direction
                opts = TURNS[(dr, dc)][:]
                rng.shuffle(opts)
                placed_turn = False
                for (ndr, ndc) in opts:
                    mt = mirror_for(dr, dc, ndr, ndc)
                    if mt is None:
                        continue
                    # tentatively the current cell (r,c) is the mirror/turn cell
                    turns.append((r, c, mt))
                    dr, dc = ndr, ndc
                    placed_turn = True
                    break
                if not placed_turn:
                    ok = False
                    break
        if not ok or len(turns) < 1 or len(path) < 2:
            continue
        cat = path[-1]
        # cat must not coincide with a turn cell
        if any((cat[0], cat[1]) == (tr, tc) for (tr, tc, _) in turns):
            continue
        return (sr, sc, d, turns, cat, occ)
    return None


def carve_and_apply(g, route):
    """Carve the route into g: corridor cells -> '.', turns kept '.' for now
    (mirrors are returned separately), cat -> 'O', laser -> dir char."""
    sr, sc, d, turns, cat, occ = route
    for (r, c) in occ:
        if g[r][c] == "#":
            g[r][c] = "."
    g[sr][sc] = d
    g[cat[0]][cat[1]] = "O"
    return turns


def build(seed):
    """Build one feasible board. Returns (text, meta) or None."""
    rng = random.Random(seed)
    H = rng.randint(24, 80)
    W = rng.randint(24, 80)
    # Few cats: the breaking regime is 3-8 cats with deep, many-turn routes.
    ncats = rng.randint(3, 7)
    multi = True  # multi-laser, one private laser per cat, broke hardest
    # solid wall fill -> we carve private corridors through it
    g = [["#" for _ in range(W)] for _ in range(H)]

    srcs = []
    planted = []   # all planted mirror cells (r,c,mt)
    routes = []
    target = ncats
    # one corridor per cat (each cat its own private winding route)
    # in single-laser mode, reuse the same laser start? No: each route has its
    # own laser. For single-laser we keep just ONE route's laser and make the
    # remaining cats hang off branch corridors of that same laser is complex;
    # instead single vs multi just bounds how many distinct lasers we allow.
    max_lasers = (target if multi else max(1, target // rng.randint(3, 6)))

    attempts = 0
    while len(routes) < target and attempts < target * 8:
        attempts += 1
        n_turns = rng.randint(4, 9)         # deep multi-turn (>=4 bends)
        seg_min = rng.randint(2, 5)
        seg_max = seg_min + rng.randint(4, 12)
        r = plant_one_route(g, H, W, rng, n_turns, seg_min, seg_max)
        if r is None:
            continue
        # respect laser budget: if we already have max_lasers, only accept
        # routes... each route needs its own laser, so cap routes at max_lasers
        if len(srcs) >= max_lasers:
            break
        turns = carve_and_apply(g, r)
        sr, sc, d, _t, cat, occ = r
        srcs.append((sr, sc, d))
        for (tr, tc, mt) in turns:
            g[tr][tc] = mt
            planted.append((tr, tc, mt))
        routes.append(r)

    if not srcs or not planted:
        return None

    # Optional decoy lasers: a few extra lasers with their own winding dead-end
    # corridors that light NO cat. They expand the solver's search (which laser
    # serves which cat?) without changing the planted solution's mirror needs.
    n_decoy = rng.randint(1, 4)
    for _ in range(n_decoy):
        n_turns = rng.randint(3, 7)
        seg_min = rng.randint(2, 4)
        seg_max = seg_min + rng.randint(3, 9)
        dr = plant_one_route(g, H, W, rng, n_turns, seg_min, seg_max)
        if dr is None:
            continue
        sr, sc, d, turns, cat, occ = dr
        # carve corridor but NO mirrors and NO cat (turn into empty dead-end)
        for (r, c) in occ:
            if g[r][c] == "#":
                g[r][c] = "."
        g[sr][sc] = d
        # the would-be cat cell stays empty
        srcs.append((sr, sc, d))

    # Simulate planted solution; keep only genuinely lit cats.
    lit = lit_cats(g, H, W, srcs)
    cats = [(r, c) for r in range(H) for c in range(W) if g[r][c] == "O"]
    for (r, c) in cats:
        if (r, c) not in lit:
            g[r][c] = "."
    kept = [(r, c) for (r, c) in cats if (r, c) in lit]
    if len(kept) < 3:
        return None

    # Erase mirrors -> puzzle input. L = #planted mirrors (tight) + small slack.
    nmir = len(planted)
    for (r, c, _mt) in planted:
        g[r][c] = "."
    slack = rng.choice([0, 0, 0, 0, 1])  # tight budget breaks the solver harder
    L = nmir + slack

    # Re-verify feasibility: re-plant mirrors, simulate, must light all kept.
    gv = [row[:] for row in g]
    for (r, c, mt) in planted:
        gv[r][c] = mt
    litv = lit_cats(gv, H, W, srcs)
    if not all((r, c) in litv for (r, c) in kept):
        return None
    if len(planted) > L:
        return None

    text = "\n".join([f"{W} {H} {L}"] + ["".join(x) for x in g]) + "\n"
    meta = dict(W=W, H=H, L=L, cats=len(kept), lasers=len(srcs),
                mirrors=nmir, multi=multi)
    return text, meta


def coverage(text, timeout=12.0):
    """Run reference solver, return (lit, total, frac) or None on failure."""
    try:
        p = subprocess.run([SOLVER], input=text.encode(), capture_output=True,
                           timeout=timeout)
    except subprocess.TimeoutExpired:
        return ("TIMEOUT", None, None)
    except Exception:
        return None
    out = p.stdout.decode(errors="replace")
    if not out.strip():
        return None
    return litcheck(text, out)


DZ = {"A": (0, -1), "V": (0, 1), "<": (-1, 0), ">": (1, 0)}


def _trace(b, x, y, dx, dy, bnd):
    H, W = len(b), len(b[0])
    s = 0
    while 0 <= y < H and 0 <= x < W:
        ch = b[y][x]
        if ch == "O":
            b[y][x] = "X"
        if ch == "#":
            break
        if ch == "/":
            dx, dy = -dy, -dx
        if ch == "\\":
            dx, dy = dy, dx
        x += dx
        y += dy
        s += 1
        if s > bnd:
            return


def _parse(txt):
    lines = txt.split("\n")
    W, H, M = map(int, lines[0].split())
    return [list(lines[1 + i]) for i in range(H)]


def litcheck(intext, outtext):
    ib = _parse(intext)
    ob = _parse(outtext)
    H, W = len(ob), len(ob[0])
    B = W * H * 2
    tot = sum(r.count("O") for r in ib)
    for y in range(H):
        for x in range(W):
            if ob[y][x] in DZ:
                _trace(ob, x, y, DZ[ob[y][x]][0], DZ[ob[y][x]][1], B)
    lit = tot - sum(r.count("O") for r in ob)
    return (lit, tot, (lit / tot if tot else 1.0))


def main():
    if len(sys.argv) >= 3 and sys.argv[1] == "--one":
        res = build(int(sys.argv[2]))
        if res:
            sys.stdout.write(res[0])
        return

    import time
    outdir = os.path.join(PROJ, "tests_chd", "hunt")
    os.makedirs(outdir, exist_ok=True)
    saved = []
    covs = []
    best = None  # lowest coverage overall (even if >=0.5)
    t0 = time.time()
    base = int(os.environ.get("HUNT_BASE", "1"))
    seeds = range(base, base + 400)
    feasible = 0
    for seed in seeds:
        if time.time() - t0 > 235:  # ~4 min wall-clock cap
            print(f"[time cap hit at seed {seed}]")
            break
        res = build(seed)
        if not res:
            continue
        text, meta = res
        feasible += 1
        cov = coverage(text)
        if cov is None:
            continue
        lit, tot, frac = cov
        if lit == "TIMEOUT":
            print(f"seed {seed}: TIMEOUT (W={meta['W']} H={meta['H']} "
                  f"cats={meta['cats']} lasers={meta['lasers']})")
            continue
        covs.append(frac)
        tag = f"W={meta['W']} H={meta['H']} L={meta['L']} cats={meta['cats']} " \
              f"lasers={meta['lasers']} multi={meta['multi']} cov={frac:.3f}"
        if best is None or frac < best[0]:
            best = (frac, seed, tag)
        if frac < 0.5:
            fn = os.path.join(outdir, f"pocket_{seed}.in")
            with open(fn, "w") as f:
                f.write(text)
            saved.append((seed, frac, meta, fn))
            print(f"SAVED seed {seed}: cov={frac:.3f} ({lit}/{tot}) {tag}")

    print("\n===== SUMMARY =====")
    print(f"feasible boards generated: {feasible}, scored: {len(covs)}")
    print(f"breaking cases saved (cov<0.5): {len(saved)}")
    if covs:
        covs_sorted = sorted(covs)
        mn = covs_sorted[0]
        med = covs_sorted[len(covs_sorted) // 2]
        print(f"coverage min={mn:.3f} median={med:.3f} max={max(covs):.3f}")
    if best:
        print(f"lowest coverage: {best[0]:.3f} at seed {best[1]} :: {best[2]}")
    if saved:
        saved.sort(key=lambda x: x[1])
        print("examples (W H L cats lasers coverage):")
        for (seed, frac, meta, fn) in saved[:5]:
            print(f"  {os.path.basename(fn)}: {meta['W']} {meta['H']} "
                  f"{meta['L']} {meta['cats']} {meta['lasers']} {frac:.3f}")


if __name__ == "__main__":
    main()
