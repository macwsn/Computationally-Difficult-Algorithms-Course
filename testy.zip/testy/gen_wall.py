#!/usr/bin/env python3
"""Adversarial generator: serpentine / dense beam paths that must DETOUR around
pre-placed WALLS. Plant-and-erase guarantees feasibility.

Idea: pre-place a wall pattern (vertical/horizontal combs with gaps, or block
obstacles). Then simulate a laser beam that weaves around the walls: it travels
straight until just before hitting a wall (or board edge), where we PLANT a
mirror to turn it, threading it through the gaps. Cats 'O' are dropped along the
beam path. Finally we ERASE the planted mirrors -> the board needs exactly that
detouring layout. L = #planted mirrors (+ slack).

Usage:
  gen_wall.py --one <seed> <pattern> <H> <W> [slack] [extra...]
patterns:
  comb_v   : vertical wall combs (columns with a gap), beam serpentines through
  comb_h   : horizontal wall combs (rows with a gap)
  blocks   : scattered rectangular block obstacles, beam weaves around
  spiral   : inward spiral hugging walls
  zigzag   : staircase walls forcing diagonal-ish detours
extra (key=val): gap=<n> period=<n> wallcol=<float> lasers=<n> dens=<int>
"""
import sys
import random

DIRS = {"A": (-1, 0), "V": (1, 0), "<": (0, -1), ">": (0, 1)}
DCHR = {(-1, 0): "A", (1, 0): "V", (0, -1): "<", (0, 1): ">"}


def refl(mt, dr, dc):
    return (-dc, -dr) if mt == "/" else (dc, dr)


def lit_cats(g, H, W, srcs):
    """Judge-consistent raytrace, bound = W*H*2."""
    lit = set()
    B = W * H * 2
    for (sr, sc, d) in srcs:
        dr, dc = DIRS[d]
        r, c = sr, sc
        step = 0
        while 0 <= r < H and 0 <= c < W:
            ch = g[r][c]
            if ch == "#":
                break
            if ch == "O":
                lit.add((r, c))
            elif ch == "/":
                dr, dc = refl("/", dr, dc)
            elif ch == "\\":
                dr, dc = refl("\\", dr, dc)
            r += dr
            c += dc
            step += 1
            if step > B:
                break
    return lit


def inb(r, c, H, W):
    return 0 <= r < H and 0 <= c < W


# choose mirror that turns incoming dir (dr,dc) into desired (ndr,ndc)
# '/' : (dr,dc)->(-dc,-dr) ; '\\': (dr,dc)->(dc,dr)
def mirror_for(dr, dc, ndr, ndc):
    if (-dc, -dr) == (ndr, ndc):
        return "/"
    if (dc, dr) == (ndr, ndc):
        return "\\"
    return None


def perpendicular(dr, dc):
    # the two perpendicular directions
    if dr == 0:
        return [(-1, 0), (1, 0)]
    return [(0, -1), (0, 1)]


class Planter:
    """Walks a beam around walls, planting turn mirrors and dropping cats."""

    def __init__(self, g, H, W, rng):
        self.g = g
        self.H = H
        self.W = W
        self.rng = rng
        self.mirrors = []  # (r,c,mt)
        self.cat_every = 1  # drop a cat every N steps along straight runs
        self.src_set = set()  # cells holding a laser source (never overwrite)

    def free(self, r, c):
        return inb(r, c, self.H, self.W) and self.g[r][c] == "."

    def open_ahead(self, r, c, dr, dc):
        """How many free cells ahead (including (r,c) start move) until wall/edge."""
        n = 0
        rr, cc = r, c
        while self.free(rr, cc):
            n += 1
            rr += dr
            cc += dc
        return n

    def walk(self, sr, sc, d, max_steps):
        """Plant a beam from (sr,sc) heading d. Returns source tuple or None."""
        g = self.g
        H, W = self.H, self.W
        if not self.free(sr, sc):
            return None
        dr, dc = DIRS[d]
        g[sr][sc] = d
        self.src_set.add((sr, sc))
        src = (sr, sc, d)
        r, c = sr + dr, sc + dc
        steps = 0
        since_turn = 0
        while steps < max_steps:
            if not self.free(r, c):
                # need to turn BEFORE entering. Back up to last free cell.
                pr, pc = r - dr, c - dc
                if not inb(pr, pc, H, W) or g[pr][pc] in "#":
                    break
                if (pr, pc) in self.src_set:
                    # can't bend on the source cell; dead end for this beam
                    break
                # try to turn at (pr,pc): pick a perpendicular dir with most room
                best = None
                bestroom = 0
                for (ndr, ndc) in perpendicular(dr, dc):
                    room = self.open_ahead(pr + ndr, pc + ndc, ndr, ndc)
                    if room > bestroom:
                        bestroom = room
                        best = (ndr, ndc)
                if best is None or bestroom == 0:
                    break
                ndr, ndc = best
                mt = mirror_for(dr, dc, ndr, ndc)
                if mt is None:
                    break
                # place mirror at (pr,pc) -- it was a cat or '.', set mirror
                if g[pr][pc] == "O":
                    # remove cat there, will be a mirror cell
                    pass
                g[pr][pc] = mt
                self.mirrors.append((pr, pc, mt))
                dr, dc = ndr, ndc
                r, c = pr + dr, pc + dc
                since_turn = 0
                continue
            # free cell: maybe drop a cat
            if g[r][c] == ".":
                g[r][c] = "O"
            r += dr
            c += dc
            steps += 1
            since_turn += 1
            # opportunistic random turn to increase mirror count / weave density
            if since_turn >= self.cat_every and self.maybe_turn(r, c, dr, dc):
                # maybe_turn handled placement; recompute dr,dc from last mirror
                pr, pc, mt = self.mirrors[-1]
                ndr, ndc = self.last_turn_dir
                dr, dc = ndr, ndc
                r, c = pr + dr, pc + dc
                since_turn = 0
        return src

    def maybe_turn(self, r, c, dr, dc):
        return False  # base: only forced turns

    last_turn_dir = (0, 0)


class WeavePlanter(Planter):
    """Adds proactive turns to thread through wall gaps and raise density."""

    def __init__(self, g, H, W, rng, turn_prob, min_run):
        super().__init__(g, H, W, rng)
        self.turn_prob = turn_prob
        self.min_run = min_run

    def maybe_turn(self, r, c, dr, dc):
        # (r,c) is the cell we're about to step into next iteration's start;
        # we are currently at having just placed cat. Decide a proactive turn at
        # the *previous* cell to bend the beam.
        if self.rng.random() > self.turn_prob:
            return False
        pr, pc = r - dr, c - dc  # cell we just lit (the turn pivot candidate)
        if not inb(pr, pc, self.H, self.W):
            return False
        if (pr, pc) in self.src_set:
            return False
        # need pivot to be a mirror-able cell (currently 'O' from our beam)
        if self.g[pr][pc] not in "O.":
            return False
        # choose perpendicular dir with at least min_run room
        opts = []
        for (ndr, ndc) in perpendicular(dr, dc):
            room = self.open_ahead(pr + ndr, pc + ndc, ndr, ndc)
            if room >= self.min_run:
                opts.append(((ndr, ndc), room))
        if not opts:
            return False
        (ndr, ndc), room = self.rng.choice(opts)
        mt = mirror_for(dr, dc, ndr, ndc)
        if mt is None:
            return False
        self.g[pr][pc] = mt
        self.mirrors.append((pr, pc, mt))
        self.last_turn_dir = (ndr, ndc)
        return True


# ---------------- wall patterns ----------------

def walls_comb_v(g, H, W, rng, period, gapw):
    """Vertical wall columns every `period`, each with a gap of width gapw at a
    pseudo-random row, leaving room for a serpentine to thread through."""
    for c in range(period, W - 1, period):
        gap = rng.randint(1, max(1, H - gapw - 1))
        for r in range(H):
            if gap <= r < gap + gapw:
                continue
            g[r][c] = "#"


def walls_comb_h(g, H, W, rng, period, gapw):
    for r in range(period, H - 1, period):
        gap = rng.randint(1, max(1, W - gapw - 1))
        for c in range(W):
            if gap <= c < gap + gapw:
                continue
            g[r][c] = "#"


def walls_blocks(g, H, W, rng, nblocks, bmin, bmax):
    for _ in range(nblocks):
        bh = rng.randint(bmin, bmax)
        bw = rng.randint(bmin, bmax)
        r0 = rng.randint(0, max(0, H - bh - 1))
        c0 = rng.randint(0, max(0, W - bw - 1))
        for r in range(r0, r0 + bh):
            for c in range(c0, c0 + bw):
                g[r][c] = "#"


def walls_zigzag(g, H, W, rng, period, seglen):
    """Staircase wall segments forcing the beam into a zigzag detour."""
    r = period
    flip = False
    while r < H - 1:
        if not flip:
            for c in range(0, min(W - 2, seglen)):
                g[r][c] = "#"
        else:
            for c in range(max(0, W - seglen), W - 1):
                g[r][c] = "#"
        flip = not flip
        r += period


def gen(seed, pattern, H, W, slack, opts):
    rng = random.Random(seed)
    g = [["." for _ in range(W)] for _ in range(H)]
    period = opts.get("period", max(4, W // 12))
    gapw = opts.get("gap", 3)
    lasers = opts.get("lasers", 1)
    turn_prob = opts.get("turnp", 0.0)
    min_run = opts.get("minrun", 3)
    wallcol = opts.get("wallcol", 0.0)

    if pattern == "comb_v":
        walls_comb_v(g, H, W, rng, period, gapw)
    elif pattern == "comb_h":
        walls_comb_h(g, H, W, rng, period, gapw)
    elif pattern == "blocks":
        nb = opts.get("nblocks", max(3, (H * W) // 400))
        walls_blocks(g, H, W, rng, nb, opts.get("bmin", 3), opts.get("bmax", 8))
    elif pattern == "zigzag":
        walls_zigzag(g, H, W, rng, period, opts.get("seglen", W - W // 4))
    elif pattern == "comb_vh":
        walls_comb_v(g, H, W, rng, period, gapw)
        walls_comb_h(g, H, W, rng, max(4, period + 1), gapw)
    # else: open (no walls) -- but family wants walls

    srcs = []
    if turn_prob > 0:
        planter = WeavePlanter(g, H, W, rng, turn_prob, min_run)
    else:
        planter = Planter(g, H, W, rng)
    planter.cat_every = opts.get("catevery", 1)

    B = W * H * 2
    # choose starts: spread along the left/top edge for serpentine threading
    starts = []
    for k in range(lasers):
        # pick a free start cell near an edge with a clear initial direction
        tries = 0
        placed = False
        while tries < 200 and not placed:
            tries += 1
            edge = rng.randint(0, 3)
            if edge == 0:  # top, go down
                sr, sc, d = 0, rng.randint(0, W - 1), "V"
            elif edge == 1:  # left, go right
                sr, sc, d = rng.randint(0, H - 1), 0, ">"
            elif edge == 2:  # right, go left
                sr, sc, d = rng.randint(0, H - 1), W - 1, "<"
            else:  # bottom, go up
                sr, sc, d = H - 1, rng.randint(0, W - 1), "A"
            if g[sr][sc] == ".":
                starts.append((sr, sc, d))
                placed = True

    for (sr, sc, d) in starts:
        s = planter.walk(sr, sc, d, B)
        if s:
            srcs.append(s)

    if not planter.mirrors or not srcs:
        return None

    # extra walls in free non-path cells
    if wallcol > 0:
        for r in range(H):
            for c in range(W):
                if g[r][c] == "." and rng.random() < wallcol:
                    g[r][c] = "#"

    # keep only genuinely lit cats (full judge sim with planted mirrors present)
    lit = lit_cats(g, H, W, srcs)
    for r in range(H):
        for c in range(W):
            if g[r][c] == "O" and (r, c) not in lit:
                g[r][c] = "."

    cats = sum(row.count("O") for row in g)
    if cats < 2:
        return None

    # ERASE planted mirrors
    planted = [(r, c, mt) for (r, c, mt) in planter.mirrors]
    for (r, c, mt) in planted:
        g[r][c] = "."

    L = len(planted) + slack
    board = "\n".join([f"{W} {H} {L}"] + ["".join(x) for x in g]) + "\n"
    # mirror file content
    mlines = "".join(f"{r} {c} {mt}\n" for (r, c, mt) in planted)
    nwalls = sum(row.count("#") for row in g)
    meta = dict(H=H, W=W, L=L, planted=len(planted), cats=cats, walls=nwalls,
                lasers=len(srcs), pattern=pattern)
    return board, mlines, meta


def parse_opts(args):
    o = {}
    for a in args:
        if "=" in a:
            k, v = a.split("=", 1)
            try:
                o[k] = int(v)
            except ValueError:
                try:
                    o[k] = float(v)
                except ValueError:
                    o[k] = v
    return o


if __name__ == "__main__":
    if len(sys.argv) >= 6 and sys.argv[1] == "--one":
        seed = int(sys.argv[2])
        pattern = sys.argv[3]
        H = int(sys.argv[4])
        W = int(sys.argv[5])
        slack = int(sys.argv[6]) if len(sys.argv) > 6 and "=" not in sys.argv[6] else 0
        rest = [a for a in sys.argv[6:] if "=" in a]
        opts = parse_opts(rest)
        res = gen(seed, pattern, H, W, slack, opts)
        if res is None:
            sys.stderr.write("GEN_FAIL\n")
            sys.exit(2)
        board, mlines, meta = res
        # optional mirror dump path via opts mout=... handled by caller writing
        sys.stderr.write(str(meta) + "\n")
        # write mirror file if MIRROUT env set
        import os
        mout = os.environ.get("MIRROUT")
        if mout:
            open(mout, "w").write(mlines)
        sys.stdout.write(board)
    else:
        print(__doc__)
