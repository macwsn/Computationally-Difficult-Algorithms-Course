#!/usr/bin/env python3
"""Multi-laser adversarial generator (plant-and-erase).

Builds feasible Checkpoint D boards where beams from DIFFERENT edges and
DIFFERENT directions INTERLEAVE / CROSS / share regions. The solver (sol8.cpp
serp_build) threads each laser sequentially and may tangle.

Plant-and-erase guarantee: for each laser we simulate its beam and place
mirrors to steer it (serpentine / U-turns), marking passed '.' cells as cats.
Then we ERASE all planted mirrors. L = #planted mirrors (+ optional slack).
Finally recompute the lit set with ALL lasers on the bare board and drop any
cat not actually lit, so the board is provably solvable with the planted set
re-inserted (verified separately with litcheck).

Coordinates: (r,c). DIRS A=(-1,0) V=(1,0) <=(0,-1) >=(0,1).
'/' : (dr,dc)->(-dc,-dr)   '\\' : (dr,dc)->(dc,dr)
"""
import sys, random, argparse

DIRS = {"A": (-1, 0), "V": (1, 0), "<": (0, -1), ">": (0, 1)}


def refl(mt, dr, dc):
    return (-dc, -dr) if mt == "/" else (dc, dr)


def in_b(r, c, H, W):
    return 0 <= r < H and 0 <= c < W


def lit_cats(g, H, W, srcs):
    """Judge-faithful simulation. bound = W*H*2."""
    lit = set()
    B = W * H * 2
    for (sr, sc, d) in srcs:
        dr, dc = DIRS[d]
        r, c = sr, sc
        step = 0
        while in_b(r, c, H, W):
            ch = g[r][c]
            if ch == "#":
                break
            if ch == "O":
                lit.add((r, c))
            elif ch == "/":
                dr, dc = refl("/", dr, dc)
            elif ch == "\\":
                dr, dc = refl("\\", dr, dc)
            r += dr
            c += dc
            step += 1
            if step > B:
                break
    return lit


class Board:
    def __init__(self, H, W):
        self.H, self.W = H, W
        self.g = [["." for _ in range(W)] for _ in range(H)]
        self.mirrors = []   # planted mirror positions (r,c)
        self.srcs = []      # (r,c,d)

    def place_src(self, r, c, d):
        self.g[r][c] = d
        self.srcs.append((r, c, d))

    def put_mirror(self, r, c, mt):
        self.g[r][c] = mt
        self.mirrors.append((r, c))

    def mark_cat(self, r, c):
        if self.g[r][c] == ".":
            self.g[r][c] = "O"


def _free(b, r, c):
    if not in_b(r, c, b.H, b.W):
        return False
    return b.g[r][c] not in ("#",) and b.g[r][c] not in DIRS


def serpentine_laser(b, r, c, d, max_mirrors, rng, walls_set, pitch=2):
    """Plant a TIGHT serpentine from (r,c) firing d. The beam sweeps a line,
    then makes a U-turn (2 mirrors) advancing `pitch` cells perpendicular, then
    sweeps back, etc. Cats dropped on every traversed '.'. Mirrors recorded.
    Returns #mirrors placed. Stops at max_mirrors, edge it can't turn at, or a
    cell already owned by another laser's mirror/source.

    A U-turn for a horizontal sweep going right (dc=1) that needs to go down by
    `pitch` then resume going left: at exit col place '\\' (right->down), travel
    down `pitch`-1 plain cells, then place '/' (down->left). Symmetric for all
    orientations using reflection tables.
    """
    H, W = b.H, b.W
    dr, dc = DIRS[d]
    cr, cc = r + dr, c + dc
    placed = 0
    guard = 0
    while placed + 2 <= max_mirrors and guard < H * W * 4:
        guard += 1
        # sweep current line until we hit edge/wall/foreign cell
        if not _free(b, cr, cc):
            break
        b.mark_cat(cr, cc)
        nr, nc = cr + dr, cc + dc
        if _free(b, nr, nc):
            cr, cc = nr, nc
            continue
        # blocked ahead -> U-turn here at (cr,cc). Decide perpendicular dir.
        # We turn 90 deg, advance pitch, turn 90 deg again (reverse along axis).
        # The exit cell holds the first turning mirror.
        if (cr, cc) in walls_set:
            break
        # candidate perpendicular directions
        perps = []
        if dr != 0:   # vertical sweep -> turn to horizontal
            perps = [(0, 1), (0, -1)]
        else:         # horizontal sweep -> turn to vertical
            perps = [(1, 0), (-1, 0)]
        rng.shuffle(perps)
        done = False
        for (pdr, pdc) in perps:
            # mirror at exit that turns (dr,dc)->(pdr,pdc)
            mt1 = None
            for cand in "/\\":
                if refl(cand, dr, dc) == (pdr, pdc):
                    mt1 = cand
            if mt1 is None:
                continue
            # advance pitch cells along perp; need them free
            path = []
            tr, tc = cr, cc
            ok = True
            for _ in range(pitch):
                tr, tc = tr + pdr, tc + pdc
                if not _free(b, tr, tc) or b.g[tr][tc] in "/\\":
                    ok = False
                    break
                path.append((tr, tc))
            if not ok or not path:
                continue
            # second mirror turns (pdr,pdc) -> (-dr,-dc) (reverse original axis)
            mt2 = None
            for cand in "/\\":
                if refl(cand, pdr, pdc) == (-dr, -dc):
                    mt2 = cand
            if mt2 is None:
                continue
            er, ec = path[-1]
            # the cell after the second turn must be free to keep sweeping
            ndr, ndc = -dr, -dc
            ar, ac = er + ndr, ec + ndc
            if not _free(b, ar, ac):
                continue
            # commit: mirror1 at (cr,cc), plain cats along path[:-1], mirror2 at end
            b.put_mirror(cr, cc, mt1)
            for (pr, pc) in path[:-1]:
                b.mark_cat(pr, pc)
            b.put_mirror(er, ec, mt2)
            placed += 2
            dr, dc = ndr, ndc
            cr, cc = ar, ac
            done = True
            break
        if not done:
            break
    return placed


def build(mode, H, W, seed, slack):
    rng = random.Random(seed)
    b = Board(H, W)
    mirror_types = {}  # (r,c) -> type, captured before erase

    # patch put_mirror to record type
    orig_put = b.put_mirror
    def put2(r, c, mt):
        orig_put(r, c, mt)
        mirror_types[(r, c)] = mt
    b.put_mirror = put2

    walls_set = set()

    BIG = H * W  # effectively "as long as it can go"

    if mode == "opposing":
        # lasers from top firing down (V) AND bottom firing up (A), interleaved
        # so their serpentines must share the middle rows.
        k = rng.choice([2, 3, 4])
        cols = sorted(rng.sample(range(0, W), min(k, W)))
        for i, sc in enumerate(cols):
            p = rng.choice([1, 2, 2, 3])
            if i % 2 == 0:
                b.place_src(0, sc, "V")
                serpentine_laser(b, 0, sc, "V", BIG, rng, walls_set, pitch=p)
            else:
                b.place_src(H - 1, sc, "A")
                serpentine_laser(b, H - 1, sc, "A", BIG, rng, walls_set, pitch=p)

    elif mode == "crossing":
        # horizontal lasers from left (>) and vertical lasers from top (V):
        # their natural sweeps cross in a grid.
        kh = rng.choice([2, 3, 4])
        kv = rng.choice([2, 3, 4])
        rows = sorted(rng.sample(range(0, H), min(kh, H)))
        cols = sorted(rng.sample(range(0, W), min(kv, W)))
        order = [("h", r) for r in rows] + [("v", c) for c in cols]
        rng.shuffle(order)
        for kind, idx in order:
            p = rng.choice([1, 2, 3])
            if kind == "h":
                b.place_src(idx, 0, ">")
                serpentine_laser(b, idx, 0, ">", BIG, rng, walls_set, pitch=p)
            else:
                b.place_src(0, idx, "V")
                serpentine_laser(b, 0, idx, "V", BIG, rng, walls_set, pitch=p)

    elif mode == "fourway":
        # one laser from each edge, all serpentining toward the center.
        p = rng.choice([1, 2, 3])
        b.place_src(0, 1, "V"); serpentine_laser(b, 0, 1, "V", BIG, rng, walls_set, pitch=p)
        b.place_src(H - 1, W - 2, "A"); serpentine_laser(b, H - 1, W - 2, "A", BIG, rng, walls_set, pitch=p)
        b.place_src(1, 0, ">"); serpentine_laser(b, 1, 0, ">", BIG, rng, walls_set, pitch=p)
        b.place_src(H - 2, W - 1, "<"); serpentine_laser(b, H - 2, W - 1, "<", BIG, rng, walls_set, pitch=p)

    elif mode == "interleave":
        # multiple > lasers NOT in clean bands: start rows packed close so their
        # serpentines interleave (each sweeps a few rows then must dodge another).
        k = rng.choice([2, 3, 4, 5])
        start_rows = sorted(rng.sample(range(0, H - 1), min(k, H - 1)))
        for sr in start_rows:
            p = rng.choice([1, 2, 3])
            b.place_src(sr, 0, ">")
            serpentine_laser(b, sr, 0, ">", BIG, rng, walls_set, pitch=p)

    elif mode == "midboard":
        # lasers placed mid-board (not on an edge) firing in mixed directions.
        k = rng.choice([3, 4, 5, 6])
        for _ in range(k):
            sr = rng.randint(1, H - 2)
            sc = rng.randint(1, W - 2)
            if b.g[sr][sc] != ".":
                continue
            d = rng.choice("AV<>")
            p = rng.choice([1, 2, 3])
            b.place_src(sr, sc, d)
            serpentine_laser(b, sr, sc, d, BIG, rng, walls_set, pitch=p)

    elif mode == "shared":
        # two lasers must share one corridor/region: place them so their bands
        # overlap heavily (same start side, interleaved pitch).
        p1 = rng.choice([2, 3, 4])
        b.place_src(0, 0, ">")
        serpentine_laser(b, 0, 0, ">", BIG, rng, walls_set, pitch=p1)
        b.place_src(H - 1, W - 1, "<")
        serpentine_laser(b, H - 1, W - 1, "<", BIG, rng, walls_set, pitch=p1)

    elif mode == "comb":
        # vertical "comb" lasers from top interleaved with horizontal sweeps:
        # vertical beams every few cols (pitch 1 -> dense) plus a couple of
        # horizontal lasers that must thread between the comb teeth.
        for sc in range(0, W, rng.choice([3, 4, 5])):
            b.place_src(0, sc, "V")
            serpentine_laser(b, 0, sc, "V", BIG, rng, walls_set, pitch=1)
        for sr in rng.sample(range(1, H - 1), min(2, H - 2)):
            b.place_src(sr, 0, ">")
            serpentine_laser(b, sr, 0, ">", BIG, rng, walls_set, pitch=2)

    else:
        raise SystemExit("unknown mode " + mode)

    L = len(b.mirrors)

    # WITNESS = board with ALL planted mirrors present (simultaneously). This is
    # the candidate solution. Compute the cats it actually lights and keep ONLY
    # those, so the witness is 100% feasible by construction.
    gw = [row[:] for row in b.g]                 # has cats 'O', sources, and mirrors
    for (r, c), mt in mirror_types.items():
        gw[r][c] = mt                            # ensure mirror chars present
    lit = lit_cats(gw, H, W, b.srcs)             # cats lit by full witness config

    # Test board: erase mirrors; keep only lit cats.
    gt = [row[:] for row in b.g]
    for (r, c) in mirror_types:
        if gt[r][c] in "/\\":
            gt[r][c] = "."
    for r in range(H):
        for c in range(W):
            if gt[r][c] == "O" and (r, c) not in lit:
                gt[r][c] = "."
            if gw[r][c] == "O" and (r, c) not in lit:
                gw[r][c] = "."                   # keep witness cats == test cats

    cats = sum(row.count("O") for row in gt)
    Lout = L + slack
    txt = "\n".join([f"{W} {H} {Lout}"] + ["".join(x) for x in gt]) + "\n"
    witness = "\n".join([f"{W} {H} {Lout}"] + ["".join(x) for x in gw]) + "\n"

    nlasers = len(b.srcs)
    dirs = "".join(d for (_, _, d) in b.srcs)
    return txt, witness, L, cats, nlasers, dirs


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("mode")
    ap.add_argument("H", type=int)
    ap.add_argument("W", type=int)
    ap.add_argument("--seed", type=int, default=1)
    ap.add_argument("--slack", type=int, default=0)
    ap.add_argument("--witness", default=None, help="write feasibility witness to this file")
    a = ap.parse_args()
    txt, witness, L, cats, nlasers, dirs = build(a.mode, a.H, a.W, a.seed, a.slack)
    sys.stderr.write(f"mode={a.mode} H={a.H} W={a.W} L={L} cats={cats} lasers={nlasers} dirs={dirs}\n")
    if a.witness:
        with open(a.witness, "w") as f:
            f.write(witness)
    sys.stdout.write(txt)
