#!/usr/bin/env python3
"""Generator feasiblnych plansz Checkpoint D (do 100x100, wiele zrodel).

Buduje plansze metoda "posadzonych luster": teren -> zrodla -> dla kazdego
zrodla idziemy wiazka i losowo stawiamy lustra (zakrety) oraz koty na trasie,
potem WYMAZUJEMY lustra. Dzieki temu istnieje rozwiazanie z <= (liczba
posadzonych luster). Koty trzymamy tylko te realnie oswietlone (pelna symulacja
zgodna z judge, bound = W*H*2).

Uzycie:
    gen_chd.py --one <seed> <mode> <H> <W> [slack]
modes: open sparse dense cave maze
slack: ile luster DODAC do budzetu L ponad minimum posadzone (domyslnie 0 = ciasno)
"""
import os
import random
import sys

DIRS = {"A": (-1, 0), "V": (1, 0), "<": (0, -1), ">": (0, 1)}


def refl(mt, dr, dc):
    return (-dc, -dr) if mt == "/" else (dc, dr)


def lit_cats(g, H, W, srcs):
    """Symulacja zgodna z judge: bound kroku = W*H*2."""
    lit = set()
    B = W * H * 2
    for (sr, sc, d) in srcs:
        dr, dc = DIRS[d]
        r, c = sr, sc
        step = 0
        while True:
            if not (0 <= r < H and 0 <= c < W):
                break
            ch = g[r][c]
            if ch == "#":
                break
            if ch == "O":
                lit.add((r, c))
            elif ch == "/":
                dr, dc = refl("/", dr, dc)
            elif ch == "\\":
                dr, dc = refl("\\", dr, dc)
            r += dr
            c += dc
            step += 1
            if step > B:
                break
    return lit


def terrain(mode, H, W, rng):
    if mode in ("open",):
        return [["." for _ in range(W)] for _ in range(H)]
    if mode == "sparse":
        return [["#" if rng.random() < 0.06 else "." for _ in range(W)] for _ in range(H)]
    if mode == "dense":
        return [["#" if rng.random() < 0.18 else "." for _ in range(W)] for _ in range(H)]
    if mode == "cave":
        g = [["#" if rng.random() < 0.45 else "." for _ in range(W)] for _ in range(H)]
        for _ in range(4):
            ng = [row[:] for row in g]
            for r in range(H):
                for c in range(W):
                    w = sum(g[(r + dr) % H][(c + dc) % W] == "#"
                            for dr in (-1, 0, 1) for dc in (-1, 0, 1))
                    ng[r][c] = "#" if w >= 5 else "."
            g = ng
        return g
    if mode == "maze":
        g = [["#" for _ in range(W)] for _ in range(H)]

        def carve(r, c):
            g[r][c] = "."
            dirs = [(-2, 0), (2, 0), (0, -2), (0, 2)]
            rng.shuffle(dirs)
            for dr, dc in dirs:
                nr, nc = r + dr, c + dc
                if 0 < nr < H and 0 < nc < W and g[nr][nc] == "#":
                    g[r + dr // 2][c + dc // 2] = "."
                    carve(nr, nc)
        sys.setrecursionlimit(100000)
        carve(1, 1)
        return g
    return [["." for _ in range(W)] for _ in range(H)]


def gen(seed, mode, H, W, slack):
    rng = random.Random(seed)
    g = terrain(mode, H, W, rng)
    nsrc = rng.randint(1, max(2, (H * W) // 400))
    placed = []
    total_m = 0
    maxm = rng.randint(H // 2, max(H, W) * 2)
    srcs = []
    B = W * H * 2

    def free():
        return [(r, c) for r in range(H) for c in range(W) if g[r][c] == "."]

    for _ in range(nsrc):
        fl = free()
        if not fl:
            break
        sr, sc = rng.choice(fl)
        d = rng.choice("AV<>")
        dr, dc = DIRS[d]
        g[sr][sc] = d
        srcs.append((sr, sc, d))
        r, c = sr + dr, sc + dc
        step = 0
        while step < B:
            if not (0 <= r < H and 0 <= c < W) or g[r][c] == "#":
                break
            if g[r][c] == ".":
                roll = rng.random()
                if roll < 0.18 and total_m < maxm:
                    mt = rng.choice("/\\")
                    g[r][c] = mt
                    placed.append((r, c))
                    total_m += 1
                    dr, dc = refl(mt, dr, dc)
                elif roll < 0.34:
                    g[r][c] = "O"
            r += dr
            c += dc
            step += 1

    if total_m < 1:
        return None
    lit = lit_cats(g, H, W, srcs)
    for r in range(H):
        for c in range(W):
            if g[r][c] == "O" and (r, c) not in lit:
                g[r][c] = "."
    if len(lit) < 2:
        return None
    for (r, c) in placed:
        g[r][c] = "."
    L = total_m + slack
    return "\n".join([f"{W} {H} {L}"] + ["".join(x) for x in g]) + "\n"


MODES = ["open", "sparse", "dense", "cave", "maze"]

if __name__ == "__main__":
    if len(sys.argv) >= 6 and sys.argv[1] == "--one":
        seed = int(sys.argv[2])
        mode = sys.argv[3]
        H = int(sys.argv[4])
        W = int(sys.argv[5])
        slack = int(sys.argv[6]) if len(sys.argv) > 6 else 0
        t = gen(seed, mode, H, W, slack)
        sys.stdout.write(t if t else "")
    else:
        print(__doc__)
