#!/usr/bin/env python3
"""Uruchom solver na wszystkich testach w katalogu i sprawdz (raytrace jak judge).
Uzycie: run_chd.py <binarka> <katalog> [limit_czasu_s]
Wypisuje: liczbe SOLVED/total, najgorsze czasy, liste niepowodzen."""
import subprocess
import sys
import time
import os
import glob

DZ = {"A": (0, -1), "V": (0, 1), "<": (-1, 0), ">": (1, 0)}


def trace(b, x, y, dx, dy, bnd):
    H, W = len(b), len(b[0])
    s = 0
    while 0 <= y < H and 0 <= x < W:
        ch = b[y][x]
        if ch == "O":
            b[y][x] = "X"
        elif ch == "#":
            break
        elif ch == "/":
            dx, dy = -dy, -dx
        elif ch == "\\":
            dx, dy = dy, dx
        x += dx; y += dy; s += 1
        if s > bnd:
            return


def parse(txt):
    lines = txt.split("\n")
    W, H, M = map(int, lines[0].split())
    g = [list(lines[1 + i]) for i in range(H)]
    return W, H, M, g


def check(inp, out):
    W, H, M, ib = parse(inp)
    _, _, _, ob = parse(out)
    # walidacja: lustra tylko na '.', limit M
    used = 0
    for y in range(H):
        for x in range(W):
            if ob[y][x] in "/\\":
                used += 1
                if ib[y][x] != ".":
                    return ("BADPLACE", 0, 0)
            elif ob[y][x] != ib[y][x]:
                return ("MISMATCH", 0, 0)
    if used > M:
        return ("TOOMANY", used, M)
    tot = sum(r.count("O") for r in ib)
    B = W * H * 2
    for y in range(H):
        for x in range(W):
            if ob[y][x] in DZ:
                dx, dy = DZ[ob[y][x]]
                trace(ob, x, y, dx, dy, B)
    lit = tot - sum(r.count("O") for r in ob)
    return ("OK" if lit == tot else "PARTIAL", lit, tot)


def main():
    binp = sys.argv[1]
    d = sys.argv[2]
    files = sorted(glob.glob(os.path.join(d, "*.in")))
    solved = 0
    times = []
    fails = []
    for f in files:
        inp = open(f).read()
        t0 = time.time()
        try:
            out = subprocess.run([binp], stdin=open(f), capture_output=True,
                                 text=True, timeout=30).stdout
        except subprocess.TimeoutExpired:
            fails.append((os.path.basename(f), "TIMEOUT>30", 0, 0)); times.append((30.0, f)); continue
        el = time.time() - t0
        times.append((el, f))
        st, lit, tot = check(inp, out)
        if st == "OK":
            solved += 1
        else:
            fails.append((os.path.basename(f), st, lit, tot))
    print(f"SOLVED {solved}/{len(files)}")
    times.sort(reverse=True)
    print("worst times:")
    for el, f in times[:8]:
        print(f"  {el:6.2f}s  {os.path.basename(f)}")
    if fails:
        print(f"FAILURES ({len(fails)}):")
        for nm, st, lit, tot in fails[:40]:
            print(f"  {nm}: {st} {lit}/{tot}")


if __name__ == "__main__":
    main()
