import subprocess,sys,os,glob
exec(open("fails.py").read().split("binp = sys.argv")[0])
EXE=sys.argv[1]
dirs=["cases","hard","big100","big","profile","tight","wallhunt","multihunt","windhunt","hunt"]
tot_s=0; tot_n=0
allfails=[]
for d in dirs:
    fs=sorted(glob.glob(os.path.join(d,"*.in")))
    sv=0
    for f in fs:
        st,lit,t=run_one(EXE,f)
        if st=="OK": sv+=1
        else: allfails.append(f)
    print(f"{d:10s} {sv}/{len(fs)}",flush=True)
    tot_s+=sv; tot_n+=len(fs)
print(f"TOTAL {tot_s}/{tot_n}")
open("allfails.txt","w").write("\n".join(allfails)+"\n")
