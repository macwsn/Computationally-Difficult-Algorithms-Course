import subprocess, sys, os, glob

DZ = {"A": (0, -1), "V": (0, 1), "<": (-1, 0), ">": (1, 0)}

def trace(b, x, y, dx, dy, bnd):
    H, W = len(b), len(b[0]); s = 0
    while 0 <= y < H and 0 <= x < W:
        ch = b[y][x]
        if ch == "O": b[y][x] = "X"
        elif ch == "#": break
        elif ch == "/": dx, dy = -dy, -dx
        elif ch == "\\": dx, dy = dy, dx
        x += dx; y += dy; s += 1
        if s > bnd: return

def run_one(binp, f, tmo=14):
    inp = open(f).read()
    try:
        out = subprocess.run([binp], stdin=open(f), capture_output=True, text=True, timeout=tmo).stdout
    except subprocess.TimeoutExpired:
        return ("TIMEOUT", 0, 0)
    lines = inp.split("\n"); W, H, M = map(int, lines[0].split())
    ib = [list(lines[1 + i]) for i in range(H)]
    ol = out.split("\n")
    if len(ol) < H + 1: return ("EMPTY", 0, 0)
    ob = [list(ol[1 + i].ljust(W, '.')[:W]) for i in range(H)]
    used = 0
    for y in range(H):
        for x in range(W):
            if ob[y][x] in "/\\":
                used += 1
                if ib[y][x] != ".": return ("BADPLACE", 0, 0)
            elif ob[y][x] != ib[y][x]: return ("MISMATCH", 0, 0)
    if used > M: return ("TOOMANY", used, M)
    tot = sum(r.count("O") for r in ib)
    B = W * H * 2
    for y in range(H):
        for x in range(W):
            if ob[y][x] in DZ:
                dx, dy = DZ[ob[y][x]]; trace(ob, x, y, dx, dy, B)
    lit = tot - sum(r.count("O") for r in ob)
    return ("OK" if lit == tot else "PARTIAL", lit, tot)

binp = sys.argv[1]
if len(sys.argv) > 2 and sys.argv[2] == "--list":
    files = [l.split()[0] for l in open(sys.argv[3]) if l.strip()]
else:
    dirs = ["cases", "hard", "big100", "big", "profile", "tight", "wallhunt", "multihunt", "windhunt", "hunt"]
    files = [f for d in dirs for f in sorted(glob.glob(os.path.join(d, "*.in")))]
solved = 0; fails = []
for f in files:
    st, lit, tot = run_one(binp, f)
    if st == "OK": solved += 1
    else: fails.append((f, st, lit, tot)); print(f"{f} {st} {lit}/{tot}", flush=True)
print(f"== SOLVED {solved}/{len(files)} ==")
with open("fails.txt", "w") as fh:
    for f, st, lit, tot in fails: fh.write(f"{f} {st} {lit}/{tot}\n")
