#!/usr/bin/env python3
"""Hunt HARD feasible Kotron Checkpoint D instances via the ROUTE angle.

Unexplored angle vs prior hunts (serpentines, mazes, rooms, dense fields):
a SMALL number of cats (3-30), each placed so it needs a SPECIFIC,
hard-to-find multi-mirror route, with structures that mislead a greedy/beam
solver:

  far       : cats far from ALL straight laser beams (0% initial coverage),
              each reachable only via a 3-6 mirror zig-zag detour. Decoy open
              corridors lead nowhere near a cat.
  comb      : "comb"/"fork" walls so most candidate turns dead-end; the one
              productive turn is deep in. The beam must thread a specific slot.
  corner    : cats clustered in a far corner reachable only by a long zig-zag
              across the whole board.
  multi     : multiple lasers whose beams must be redirected with care; cats
              sit where only a coordinated routing reaches them.

All strategies PLANT a real solution: place laser(s), trace the beam, place
mirrors to steer it to each cat, simulate (judge bound = W*H*2), keep only the
cats actually lit, then ERASE the mirrors and set L = #planted (+ slack).
Re-verify feasibility (the planted mirrors relit all kept cats) before saving.

Usage:
  gen_hunt_route.py run [nseeds] [time_budget_s]
  gen_hunt_route.py --one <seed> <strat> <H> <W> [slack]
"""
import os
import random
import subprocess
import sys
import time

DIRS = {"A": (-1, 0), "V": (1, 0), "<": (0, -1), ">": (0, 1)}
REF = "/tmp/sol8ref"
HUNT_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "hunt")
TIMEOUT = 12.0


def refl(mt, dr, dc):
    return (-dc, -dr) if mt == "/" else (dc, dr)


def lit_cats(g, H, W, srcs):
    """Judge-consistent simulation; step bound = W*H*2 per source."""
    lit = set()
    B = W * H * 2
    for (sr, sc, d) in srcs:
        dr, dc = DIRS[d]
        r, c = sr, sc
        step = 0
        while True:
            if not (0 <= r < H and 0 <= c < W):
                break
            ch = g[r][c]
            if ch == "#":
                break
            if ch == "O":
                lit.add((r, c))
            elif ch == "/":
                dr, dc = refl("/", dr, dc)
            elif ch == "\\":
                dr, dc = refl("\\", dr, dc)
            r += dr
            c += dc
            step += 1
            if step > B:
                break
    return lit


def in_b(r, c, H, W):
    return 0 <= r < H and 0 <= c < W


# --------------------------------------------------------------------------
# Planting primitive: walk the beam along a chosen list of waypoint turns.
# We build the path explicitly, dropping a mirror at each turn, and a cat at
# the very end (and optionally mid-segment). Mirror type chosen to realize the
# requested incoming->outgoing direction transition exactly.
# --------------------------------------------------------------------------

def mirror_for(d_in, d_out):
    """Return mirror char that turns d_in into d_out, or None if not a turn."""
    dr, dc = DIRS[d_in]
    odr, odc = DIRS[d_out]
    if refl("/", dr, dc) == (odr, odc):
        return "/"
    if refl("\\", dr, dc) == (odr, odc):
        return "\\"
    return None


def plant_path(g, H, W, sr, sc, d0, turns):
    """Place laser at (sr,sc) dir d0, then follow `turns`: list of
    (steps, new_dir). At each turn vertex place the right mirror. Returns
    (placed_mirrors, end_pos, end_dir, path_cells) or None if blocked/invalid.
    Does NOT place laser cell; caller sets it. path_cells are '.' cells passed
    through (candidates for cats)."""
    if g[sr][sc] != ".":
        return None
    placed = []
    path_cells = []
    r, c = sr, sc
    d = d0
    dr, dc = DIRS[d]
    for (steps, nd) in turns:
        # advance `steps` empty cells in current dir
        for _ in range(steps):
            r += dr
            c += dc
            if not in_b(r, c, H, W) or g[r][c] != ".":
                return None
            path_cells.append((r, c))
        # at the turn vertex, place a mirror
        mt = mirror_for(d, nd)
        if mt is None:
            return None
        if g[r][c] != ".":
            return None
        g[r][c] = mt
        placed.append((r, c))
        # remove last path cell (it is now a mirror)
        if path_cells and path_cells[-1] == (r, c):
            path_cells.pop()
        d = nd
        dr, dc = DIRS[d]
    return placed, (r, c), d, path_cells


def carve_box(g, H, W, r0, c0, r1, c1, rng, fill="#"):
    for r in range(r0, r1 + 1):
        for c in range(c0, c1 + 1):
            if in_b(r, c, H, W):
                g[r][c] = fill


# --------------------------------------------------------------------------
# Strategy builders. Each returns (g, srcs, placed_mirrors) or None.
# --------------------------------------------------------------------------

def build_far(seed, H, W, rng):
    """One laser. Beam shoots straight (decoy) past open space lighting nothing.
    A few cats sit in pockets reachable only by a multi-mirror detour planted
    off the main beam. Surround board interior with scattered walls to make the
    straight path the obvious-but-wrong choice."""
    g = [["." for _ in range(W)] for _ in range(H)]
    # sprinkle decoy walls (low density so lots of open decoy corridors)
    for r in range(H):
        for c in range(W):
            if rng.random() < 0.05:
                g[r][c] = "#"

    # laser on an edge, shooting inward
    side = rng.choice("AV<>")
    if side == ">":
        sr, sc, d = rng.randint(0, H - 1), 0, ">"
    elif side == "<":
        sr, sc, d = rng.randint(0, H - 1), W - 1, "<"
    elif side == "V":
        sr, sc, d = 0, rng.randint(0, W - 1), "V"
    else:
        sr, sc, d = H - 1, rng.randint(0, W - 1), "A"
    # clear a straight decoy corridor along the laser line so it goes far
    dr, dc = DIRS[d]
    r, c = sr, sc
    for _ in range(max(H, W)):
        if not in_b(r, c, H, W):
            break
        g[r][c] = "."
        r += dr
        c += dc

    # build 3-7 cats, each via its own detour branching off the beam line
    placed_all = []
    ncats = rng.randint(3, 12)
    # Detours branch from points along the beam line. We plant a sequence of
    # turns producing a zigzag of 3-6 mirrors ending at a cat.
    beam_pts = []
    r, c = sr + dr, sc + dc
    while in_b(r, c, H, W) and g[r][c] == ".":
        beam_pts.append((r, c, d))
        r += dr
        c += dc
    if len(beam_pts) < 6:
        return None

    # We can only physically realize ONE branch off the single straight beam in
    # a planted-solution sense (the beam continues straight unless we turn it).
    # So: pick a turn point, turn the beam into a long multi-mirror zigzag that
    # threads ALL cats. The straight continuation is the decoy.
    # Reset: place laser, then plant a zigzag from a chosen turn vertex.
    g2 = [row[:] for row in g]
    # choose turn vertex some distance along the beam
    tk = rng.randint(2, max(2, len(beam_pts) - 3))
    tr, tc, _ = beam_pts[tk]
    # clear a generous region for the zigzag so planting succeeds
    # build turns: alternate perpendicular directions, random segment lengths
    if d in ("<", ">"):
        perp = ["A", "V"]
    else:
        perp = ["<", ">"]
    turns = []
    # first turn from d to a perpendicular
    cur = rng.choice(perp)
    nseg = rng.randint(3, 6)
    for i in range(nseg):
        steps = rng.randint(2, max(3, min(H, W) // 3))
        turns.append((steps, cur))
        # next direction: turn 90 deg again, alternating between along/perp axis
        if cur in ("A", "V"):
            cur = rng.choice(["<", ">"])
        else:
            cur = rng.choice(["A", "V"])
    # The first segment's "steps" is distance from laser to first turn vertex.
    turns[0] = (tk + 1, turns[0][1])

    # Pre-clear cells we plan to traverse by simulating placement on a copy that
    # treats walls as blocking; if blocked, clear them (carve path) so plant ok.
    # Simpler: clear the whole interior band lightly then plant.
    res = try_plant_zigzag(g2, H, W, sr, sc, d, turns, rng)
    if res is None:
        return None
    placed, path_cells = res
    g2[sr][sc] = d
    srcs = [(sr, sc, d)]
    # place cats: at path end and a few mid-path cells far from straight beam
    cat_candidates = [p for p in path_cells]
    rng.shuffle(cat_candidates)
    nplace = min(len(cat_candidates), rng.randint(3, 10))
    for (r, c) in cat_candidates[:nplace]:
        if g2[r][c] == ".":
            g2[r][c] = "O"
    return g2, srcs, placed


def try_plant_zigzag(g, H, W, sr, sc, d, turns, rng):
    """Try to plant; if a cell along the way is a wall, clear it (carve) and
    retry once. Returns (placed, path_cells) or None."""
    for attempt in range(2):
        # clear laser cell
        save = [row[:] for row in g]
        if g[sr][sc] != ".":
            g[sr][sc] = "."
        res = plant_path(g, H, W, sr, sc, d, turns)
        if res is not None:
            placed, end, ed, path_cells = res
            return placed, path_cells
        # restore and carve a tube along the intended geometric path, then retry
        for r in range(H):
            for c in range(W):
                g[r][c] = save[r][c]
        # carve: walk geometrically clearing cells (ignore walls), then retry
        r, c = sr, sc
        dd = d
        dr, dc = DIRS[dd]
        ok = True
        carved = []
        for (steps, nd) in turns:
            for _ in range(steps):
                r += dr
                c += dc
                if not in_b(r, c, H, W):
                    ok = False
                    break
                if g[r][c] in DIRS or g[r][c] in "/\\O":
                    ok = False
                    break
                carved.append((r, c))
            if not ok:
                break
            dd = nd
            dr, dc = DIRS[dd]
        if not ok:
            for r2 in range(H):
                for c2 in range(W):
                    g[r2][c2] = save[r2][c2]
            return None
        for (r2, c2) in carved:
            g[r2][c2] = "."
    return None


def build_corner(seed, H, W, rng):
    """Cats clustered in a far corner; long zigzag from laser across the board.
    Heavy decoy walls everywhere except a thin planted route."""
    g = [["#" if rng.random() < 0.12 else "." for _ in range(W)] for _ in range(H)]
    # laser top-left-ish, target bottom-right corner cluster
    sr, sc, d = rng.randint(0, 2), 0, ">"
    g[sr][sc] = "."
    # plant a long zigzag aiming toward bottom-right
    turns = []
    cur = ">"
    # alternate >,V,>,V ... descending toward corner
    nseg = rng.randint(4, 8)
    for i in range(nseg):
        if i % 2 == 0:
            steps = rng.randint(3, max(4, W // 3))
            cur = ">"
        else:
            steps = rng.randint(3, max(4, H // 3))
            cur = "V"
        turns.append((steps, cur))
    turns[0] = (turns[0][0], ">")  # first move stays > until first turn
    # actually first turn must change direction; start dir is '>', first turn->V
    turns = []
    cur = "V"
    nseg = rng.randint(4, 8)
    for i in range(nseg):
        if i % 2 == 0:
            steps = rng.randint(3, max(4, H // 4))
            cur = "V"
        else:
            steps = rng.randint(3, max(4, W // 4))
            cur = ">"
        turns.append((steps, cur))
    res = try_plant_zigzag(g, H, W, sr, sc, d, turns, rng)
    if res is None:
        return None
    placed, path_cells = res
    g[sr][sc] = d
    srcs = [(sr, sc, d)]
    # cats: last several path cells (the far corner cluster) + a couple earlier
    if len(path_cells) < 4:
        return None
    tail = path_cells[-rng.randint(3, min(10, len(path_cells))):]
    for (r, c) in tail:
        if g[r][c] == ".":
            g[r][c] = "O"
    # add a couple cats earlier on the route too
    for (r, c) in rng.sample(path_cells, min(3, len(path_cells))):
        if g[r][c] == ".":
            g[r][c] = "O"
    return g, srcs, placed


def build_comb(seed, H, W, rng):
    """Comb/fork walls: vertical wall teeth create many dead-end slots; the beam
    must enter ONE specific slot via a planted turn to reach cats behind it."""
    g = [["." for _ in range(W)] for _ in range(H)]
    # build comb teeth: vertical walls with gaps, like |_|_|_
    spacing = rng.randint(3, 5)
    for c in range(2, W - 2, spacing):
        toothlen = rng.randint(H // 2, H - 2)
        top = rng.random() < 0.5
        for k in range(toothlen):
            r = k if top else (H - 1 - k)
            if in_b(r, c, H, W):
                g[r][c] = "#"
    sr, sc, d = rng.randint(1, H - 2), 0, ">"
    g[sr][sc] = "."
    # plant a route: go right some, turn into a slot, snake to cats
    turns = []
    cur = ">"
    nseg = rng.randint(3, 6)
    for i in range(nseg):
        if i % 2 == 0:
            cur = rng.choice(["A", "V"])
            steps = rng.randint(2, max(3, H // 4))
        else:
            cur = ">"
            steps = rng.randint(2, max(3, W // 4))
        turns.append((steps, cur))
    # first segment travels right before first turn
    turns[0] = (rng.randint(spacing, 2 * spacing), turns[0][1])
    res = try_plant_zigzag(g, H, W, sr, sc, d, turns, rng)
    if res is None:
        return None
    placed, path_cells = res
    g[sr][sc] = d
    srcs = [(sr, sc, d)]
    if len(path_cells) < 3:
        return None
    for (r, c) in rng.sample(path_cells, min(len(path_cells), rng.randint(3, 8))):
        if g[r][c] == ".":
            g[r][c] = "O"
    return g, srcs, placed


def build_deep(seed, H, W, rng):
    """A long boustrophedon (serpentine) route that NEVER self-intersects by
    construction, on a big mostly-walled board so the route is the ONLY path.
    Tight L (= #planted turns). The route lights nothing for long stretches
    (cats placed only on later legs), so a beam search must commit to a deep,
    unrewarded path to light most cats. High L => large search depth.

    Geometry: laser enters left edge of row r0 going '>'. On each leg it runs
    along a row to a column band edge, then a 2-mirror U-turn drops it `gap`
    rows down to the next leg going the opposite way. We place '/' and '\\' to
    realize each U-turn exactly."""
    # OPEN board: every cell is a potential turn, so the serpentine threading is
    # one of combinatorially many candidate routes. This is what stresses a beam
    # search (vs an all-walls tube where the path is forced). Optionally sprinkle
    # a few walls but keep the route region open.
    open_mode = (seed % 2 == 0)
    if open_mode:
        g = [["." for _ in range(W)] for _ in range(H)]
    else:
        g = [["#" for _ in range(W)] for _ in range(H)]
    c_lo, c_hi = 1, W - 2          # horizontal travel band
    gap = rng.randint(2, 3)        # rows between legs (>=2 so U-turn fits)
    r0 = 1
    sr, sc = r0, 0
    g[sr][sc] = "."                # laser cell (set char later)
    mirror_plan = []               # (r, c, char) applied AFTER all carving
    legs = []                      # list of (row, going_right) for cat candidates
    r = r0
    going_right = True
    # Carve all leg rows + vertical U-turn channels first; stamp mirrors last so
    # later carves cannot overwrite an earlier mirror.
    while r <= H - 2:
        for c in range(c_lo, c_hi + 1):
            g[r][c] = "."
        if r == r0:
            g[r][0] = "."
        legs.append((r, going_right))
        nr = r + gap
        if nr > H - 2:
            break
        far_c = c_hi if going_right else c_lo
        for rr in range(r, nr + 1):
            g[rr][far_c] = "."
        d_in = ">" if going_right else "<"
        d_out = "<" if going_right else ">"
        mirror_plan.append((r, far_c, mirror_for(d_in, "V")))   # horiz -> down
        mirror_plan.append((nr, far_c, mirror_for("V", d_out)))  # down -> horiz
        going_right = not going_right
        r = nr
    if len(mirror_plan) < 6:
        return None
    placed = []
    for (mr, mc, mch) in mirror_plan:
        g[mr][mc] = mch
        placed.append((mr, mc))
    srcs = [(sr, sc, ">")]
    g[sr][sc] = ">"
    # candidate cat cells: interior of each leg row (exclude mirror columns)
    cand = []
    for (lr, gr) in legs:
        for c in range(c_lo, c_hi + 1):
            if g[lr][c] == ".":
                cand.append((lr, c, lr))   # tag with row for "depth"
    if len(cand) < 6:
        return None
    # bias cats to deeper legs (higher row index = later on route)
    cand.sort(key=lambda x: x[2])
    deep = [(r, c) for (r, c, _) in cand[len(cand) // 2:]]
    early = [(r, c) for (r, c, _) in cand[:len(cand) // 2]]
    k = min(len(deep), rng.randint(8, 24))
    for (r, c) in rng.sample(deep, k):
        if g[r][c] == ".":
            g[r][c] = "O"
    for (r, c) in rng.sample(early, min(2, len(early))):
        if g[r][c] == ".":
            g[r][c] = "O"
    return g, srcs, placed


def build_bait(seed, H, W, rng):
    """Bait-and-bury. The beam (1 laser) can take a SHORT greedy detour that
    lights 1-2 bait cats then dead-ends at a wall. The MANY real cats sit at the
    end of a long deep zigzag that lights nothing until the very end. With tight
    L, a greedy/beam solver that grabs bait first follows the wrong branch.

    We plant ONLY the real (deep) route + its cats as the feasible solution; the
    bait cats are NOT lit by our planted solution, so finalize() drops them...
    which would defeat the bait. So instead we make bait cats reachable by the
    SAME beam but EARLIER on the deep route is impossible (beam is one line).
    Trick: put bait cats on the straight laser line BEFORE the first turn, so a
    no-mirror or 1-mirror placement near them is tempting, while the deep route
    needs the beam turned at exactly the right cell. The straight-line bait cats
    ARE lit (laser passes them) so they stay; the deep cats need the route."""
    g = [["." for _ in range(W)] for _ in range(H)]
    # scattered decoy walls
    for r in range(H):
        for c in range(W):
            if rng.random() < 0.07:
                g[r][c] = "#"
    sr, sc, d = rng.randint(2, H - 3), 0, ">"
    # clear the laser's straight line fully (so bait cats on it are auto-lit)
    for c in range(W):
        g[sr][c] = "."
    # place 1-3 bait cats far out on the straight line (auto-lit, 0 mirrors)
    nbait = rng.randint(1, 3)
    bait_cols = sorted(rng.sample(range(W // 2, W - 1), nbait))
    for bc in bait_cols:
        g[sr][bc] = "O"
    # Now plant a deep route that turns OFF the straight line early, then snakes
    # far away to a cluster of many cats. The turn must happen at an early col so
    # the solver, lured by the easy straight-line bait, must ALSO discover this.
    turn_col = rng.randint(2, max(3, W // 6))
    turns = [(turn_col, rng.choice(["A", "V"]))]
    cur = turns[0][1]
    nseg = rng.randint(4, 7)
    for i in range(nseg):
        if cur in ("A", "V"):
            cur = rng.choice(["<", ">"])
            steps = rng.randint(3, max(4, W // 4))
        else:
            cur = rng.choice(["A", "V"])
            steps = rng.randint(3, max(4, H // 4))
        turns.append((steps, cur))
    res = try_plant_zigzag(g, H, W, sr, sc, d, turns, rng)
    if res is None:
        return None
    placed, path_cells = res
    g[sr][sc] = d
    srcs = [(sr, sc, d)]
    if len(path_cells) < 4:
        return None
    # bury MANY cats along the deep tail (the hard-to-reach cluster)
    tail = path_cells[len(path_cells) // 2:]
    k = min(len(tail), rng.randint(6, 16))
    for (r, c) in rng.sample(tail, k):
        if g[r][c] == ".":
            g[r][c] = "O"
    return g, srcs, placed


def build_multi(seed, H, W, rng):
    """Two lasers whose straight beams light a few easy cats; a cluster of cats
    sits where ONLY a coordinated multi-mirror redirection of one beam reaches.
    Tight L forces the solver to spend its whole budget on the hard cluster."""
    g = [["." for _ in range(W)] for _ in range(H)]
    for r in range(H):
        for c in range(W):
            if rng.random() < 0.06:
                g[r][c] = "#"
    srcs = []
    placed = []
    # laser 1: top edge going down, straight line lights 1-2 easy cats (decoy)
    s1c = rng.randint(1, W - 2)
    for r in range(H):
        g[r][s1c] = "."
    g[0][s1c] = "V"
    srcs.append((0, s1c, "V"))
    for r in rng.sample(range(2, H - 1), min(2, max(1, (H - 3)))):
        if g[r][s1c] == ".":
            g[r][s1c] = "O"
    # laser 2: left edge going right; we plant a deep zigzag from it to a cluster
    s2r = rng.randint(2, H - 3)
    g[s2r][0] = "."
    turns = [(rng.randint(2, max(3, W // 6)), rng.choice(["A", "V"]))]
    cur = turns[0][1]
    nseg = rng.randint(3, 6)
    for i in range(nseg):
        if cur in ("A", "V"):
            cur = rng.choice(["<", ">"]); steps = rng.randint(3, max(4, W // 4))
        else:
            cur = rng.choice(["A", "V"]); steps = rng.randint(3, max(4, H // 4))
        turns.append((steps, cur))
    res = try_plant_zigzag(g, H, W, s2r, 0, ">", turns, rng)
    if res is None:
        return None
    p2, path2 = res
    g[s2r][0] = ">"
    srcs.append((s2r, 0, ">"))
    placed = p2
    if len(path2) < 4:
        return None
    tail = path2[len(path2) // 3:]
    k = min(len(tail), rng.randint(5, 12))
    for (r, c) in rng.sample(tail, k):
        if g[r][c] == ".":
            g[r][c] = "O"
    return g, srcs, placed


STRATS = {
    "far": build_far,
    "corner": build_corner,
    "comb": build_comb,
    "bait": build_bait,
    "multi": build_multi,
    "deep": build_deep,
}


def finalize(built, slack, rng):
    """Given (g, srcs, placed), simulate to keep only lit cats, erase mirrors,
    set L. Return (text, W, H, L, ncats, nlas, planted) or None."""
    g, srcs, placed = built
    H, W = len(g), len(g[0])
    lit = lit_cats(g, H, W, srcs)
    # drop unlit cats
    for r in range(H):
        for c in range(W):
            if g[r][c] == "O" and (r, c) not in lit:
                g[r][c] = "."
    ncats = sum(row.count("O") for row in g)
    if ncats < 3:
        return None
    # erase mirrors
    for (r, c) in placed:
        g[r][c] = "."
    # feasibility re-verify: re-place planted mirrors, simulate, all cats lit
    g2 = [row[:] for row in g]
    # we lost mirror types; re-derive by re-planting is complex. Instead store
    # types when placing -> placed holds (r,c); re-simulate WITH the solution
    # board (before erase) already done. So just trust lit set == cats now.
    cats_now = {(r, c) for r in range(H) for c in range(W) if g[r][c] == "O"}
    L = len(placed) + slack
    if L < 1:
        L = 1
    text = "\n".join([f"{W} {H} {L}"] + ["".join(x) for x in g]) + "\n"
    nlas = len(srcs)
    return text, W, H, L, ncats, nlas, len(placed), cats_now


def verify_feasible(text, placed_with_types, srcs):
    """Re-place the recorded mirrors on the emitted board and confirm every cat
    is lit within bound and mirror count <= L."""
    lines = text.split("\n")
    W, H, L = map(int, lines[0].split())
    g = [list(lines[1 + i]) for i in range(H)]
    cats = {(r, c) for r in range(H) for c in range(W) if g[r][c] == "O"}
    for (r, c, mt) in placed_with_types:
        if g[r][c] != ".":
            return False
        g[r][c] = mt
    if len(placed_with_types) > L:
        return False
    lit = lit_cats(g, H, W, srcs)
    return cats.issubset(lit)


# We need mirror types for verification. Refactor: builders return placed as
# (r,c); but the mirror char is on the board at plant time. Capture types in
# finalize BEFORE erasing.

def finalize2(built, slack):
    g, srcs, placed = built
    H, W = len(g), len(g[0])
    lit = lit_cats(g, H, W, srcs)
    for r in range(H):
        for c in range(W):
            if g[r][c] == "O" and (r, c) not in lit:
                g[r][c] = "."
    ncats = sum(row.count("O") for row in g)
    if ncats < 3:
        return None
    placed_types = [(r, c, g[r][c]) for (r, c) in placed]
    for (r, c) in placed:
        g[r][c] = "."
    L = len(placed) + slack
    if L < 1:
        L = 1
    text = "\n".join([f"{W} {H} {L}"] + ["".join(x) for x in g]) + "\n"
    if not verify_feasible(text, placed_types, srcs):
        return None
    return text, W, H, L, ncats, len(srcs), len(placed)


def run_solver(text):
    try:
        p = subprocess.run([REF], input=text, capture_output=True, text=True,
                           timeout=TIMEOUT)
        return p.stdout
    except subprocess.TimeoutExpired:
        return None
    except Exception:
        return None


def coverage(in_text, out_text):
    """Return lit/total fraction from solver output, judge-consistent."""
    il = in_text.split("\n")
    W, H, L = map(int, il[0].split())
    ib = [list(il[1 + i]) for i in range(H)]
    ol = out_text.split("\n")
    if len(ol) < 1 + H:
        return None
    try:
        oW, oH, oL = map(int, ol[0].split())
    except Exception:
        return None
    ob = [list(ol[1 + i].ljust(W)) for i in range(H)]
    # validate mirrors only on '.' and count
    used = 0
    for r in range(H):
        for c in range(W):
            ch = ob[r][c]
            if ch in "/\\":
                used += 1
                if ib[r][c] != ".":
                    return None
            elif ch != ib[r][c] and not (ib[r][c] == "O" and ch in "OX"):
                # solver must preserve fixed cells
                if ib[r][c] in ".O" and ch in "/\\":
                    pass
                else:
                    return None
    if used > L:
        return None
    tot = sum(row.count("O") for row in ib)
    if tot == 0:
        return None
    B = W * H * 2
    DZ = {"A": (-1, 0), "V": (1, 0), "<": (0, -1), ">": (0, 1)}
    lit = 0
    for r in range(H):
        for c in range(W):
            if ob[r][c] in DZ:
                dr, dc = DZ[ob[r][c]]
                rr, cc = r, c
                step = 0
                while in_b(rr, cc, H, W):
                    cch = ob[rr][cc]
                    if cch == "#":
                        break
                    if cch == "O":
                        ob[rr][cc] = "X"
                    elif cch == "/":
                        dr, dc = refl("/", dr, dc)
                    elif cch == "\\":
                        dr, dc = refl("\\", dr, dc)
                    rr += dr
                    cc += dc
                    step += 1
                    if step > B:
                        break
    litn = tot - sum(row.count("O") for row in ob)
    return litn / tot, litn, tot


STRAT_SALT = {"far": 101, "corner": 211, "comb": 307, "bait": 409,
              "multi": 503, "deep": 601}


def gen_one(seed, strat, H, W, slack):
    rng = random.Random(seed * 1000003 + STRAT_SALT[strat] + slack * 17 + H * 31 + W * 13)
    builder = STRATS[strat]
    try:
        built = builder(seed, H, W, rng)
    except RecursionError:
        return None
    if built is None:
        return None
    return finalize2(built, slack)


def main_run(nseeds, budget):
    os.makedirs(HUNT_DIR, exist_ok=True)
    t0 = time.time()
    saved = []
    covs = []
    tried = 0
    # Bias toward larger boards + tight L: hard routes live there.
    sizes = [(32, 32), (40, 40), (50, 50), (60, 60), (80, 80), (100, 100),
             (50, 100), (100, 50), (70, 100), (100, 100)]
    strat_list = list(STRATS.keys())
    seed = 0
    while seed < nseeds and (time.time() - t0) < budget:
        seed += 1
        strat = strat_list[seed % len(strat_list)]
        H, W = sizes[seed % len(sizes)]
        slack = 0 if (seed % 4) else 1  # mostly tight L
        res = gen_one(seed, strat, H, W, slack)
        if res is None:
            continue
        text, Wq, Hq, L, ncats, nlas, planted = res
        tried += 1
        out = run_solver(text)
        if out is None:
            continue
        cov = coverage(text, out)
        if cov is None:
            continue
        frac, litn, tot = cov
        covs.append((frac, strat, Wq, Hq, L, ncats, nlas, seed))
        if frac < 0.5:
            fn = os.path.join(HUNT_DIR, f"route_{seed}.in")
            with open(fn, "w") as f:
                f.write(text)
            saved.append((fn, frac, strat, Wq, Hq, L, ncats, nlas))
        if (time.time() - t0) > budget:
            break

    covs.sort()
    print(f"=== ROUTE HUNT done: tried(feasible+solved)={tried} seeds_scanned={seed} elapsed={time.time()-t0:.1f}s")
    print(f"breakers saved (cov<0.5): {len(saved)}")
    if covs:
        fr = [c[0] for c in covs]
        fr.sort()
        med = fr[len(fr) // 2]
        print(f"coverage min={fr[0]:.3f} median={med:.3f} max={fr[-1]:.3f} (n={len(fr)})")
        print("lowest 8 coverage instances (frac strat WxH L cats las seed):")
        for (frac, strat, Wq, Hq, L, ncats, nlas, sd) in covs[:8]:
            print(f"  {frac:.3f}  {strat:7s} {Wq}x{Hq} L={L} cats={ncats} las={nlas} seed={sd}")
    if saved:
        print("saved breakers:")
        for (fn, frac, strat, Wq, Hq, L, ncats, nlas) in sorted(saved, key=lambda x: x[1]):
            print(f"  {os.path.basename(fn)}: {Wq} {Hq} {L} {ncats} {nlas} cov={frac:.3f} [{strat}]")
    else:
        print("NO breakers below 0.5.")
    return saved, covs


if __name__ == "__main__":
    if len(sys.argv) >= 2 and sys.argv[1] == "--one":
        seed = int(sys.argv[2])
        strat = sys.argv[3]
        H = int(sys.argv[4])
        W = int(sys.argv[5])
        slack = int(sys.argv[6]) if len(sys.argv) > 6 else 0
        res = gen_one(seed, strat, H, W, slack)
        if res:
            sys.stdout.write(res[0])
    elif len(sys.argv) >= 2 and sys.argv[1] == "run":
        nseeds = int(sys.argv[2]) if len(sys.argv) > 2 else 400
        budget = float(sys.argv[3]) if len(sys.argv) > 3 else 240.0
        main_run(nseeds, budget)
    else:
        print(__doc__)
