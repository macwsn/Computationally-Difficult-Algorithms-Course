import sys, glob, os
exec(open("fails.py").read().split("binp = sys.argv")[0])
EXE = sys.argv[1]
# Only sweep volatile dirs; cases/big100/big/profile/tight are always 100% (skip).
VOL = ["hard", "wallhunt", "multihunt", "windhunt", "hunt"]
fails = []
for d in VOL:
    for f in sorted(glob.glob(os.path.join(d, "*.in"))):
        st, lit, tot = run_one(EXE, f, tmo=15)
        if st != "OK":
            fails.append(f.replace("\\", "/"))
            print(f"FAIL {f} {lit}/{tot}", flush=True)
open("focus.txt", "w").write("\n".join(fails) + "\n")
print(f"=== {len(fails)} failing -> focus.txt ===")
# regression guard: 3 boards from each always-pass dir
guard = []
for d in ["cases", "hard", "big100", "big", "profile", "tight"]:
    guard += sorted(glob.glob(os.path.join(d, "*.in")))[:3]
open("guard.txt", "w").write("\n".join(x.replace("\\","/") for x in guard) + "\n")
print(f"guard.txt = {len(guard)} stable boards")
