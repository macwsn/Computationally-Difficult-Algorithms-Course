#!/usr/bin/env python3
"""Hunt hard ROOMS-AND-CORRIDORS instances for Kotron Checkpoint D.

Strategy: partition the board into rectangular rooms separated by walls,
connect rooms only by 1-wide doorways. Place lasers in some rooms; plant beams
that route (via mirrors = turns) out of one room, through doorways, into OTHER
rooms to reach cats. Then erase mirrors, keep only genuinely-lit cats, and set
L = number of planted mirrors (+ optional slack). This guarantees feasibility.

We then run the reference solver and keep instances where coverage < 0.5.

Usage:
    gen_hunt_rooms.py            # run the hunt (writes breaking cases)
    gen_hunt_rooms.py --one SEED # print one generated instance to stdout
"""
import os
import random
import subprocess
import sys
import time

DIRS = {"A": (-1, 0), "V": (1, 0), "<": (0, -1), ">": (0, 1)}
TURNS = "AV<>"
HERE = os.path.dirname(os.path.abspath(__file__))
PROJ = os.path.dirname(HERE)
HUNT = os.path.join(HERE, "hunt")
SOLVER = "/tmp/sol8ref"


def refl(mt, dr, dc):
    return (-dc, -dr) if mt == "/" else (dc, dr)


def lit_cats(g, H, W, srcs):
    """Judge-faithful simulation, bound = W*H*2 steps per laser."""
    lit = set()
    B = W * H * 2
    for (sr, sc, d) in srcs:
        dr, dc = DIRS[d]
        r, c = sr, sc
        step = 0
        while True:
            if not (0 <= r < H and 0 <= c < W):
                break
            ch = g[r][c]
            if ch == "#":
                break
            if ch == "O":
                lit.add((r, c))
            elif ch == "/":
                dr, dc = refl("/", dr, dc)
            elif ch == "\\":
                dr, dc = refl("\\", dr, dc)
            r += dr
            c += dc
            step += 1
            if step > B:
                break
    return lit


# ----- mirror choice that turns direction (dr,dc) -> (ndr,ndc) -----
def mirror_for(dr, dc, ndr, ndc):
    """Return mirror char ('/' or '\\') that turns (dr,dc) into (ndr,ndc), or None."""
    if refl("/", dr, dc) == (ndr, ndc):
        return "/"
    if refl("\\", dr, dc) == (ndr, ndc):
        return "\\"
    return None


def build_rooms(H, W, rng):
    """Partition into a grid of rectangular rooms separated by walls; carve
    1-wide doorways on shared walls. Returns (grid, rooms, doors).

    grid: '#' walls / '.' floor.
    rooms: list of (r0,r1,c0,c1) inclusive interior bounds (floor region).
    """
    g = [["." for _ in range(W)] for _ in range(H)]
    # outer wall
    for r in range(H):
        g[r][0] = g[r][W - 1] = "#"
    for c in range(W):
        g[0][c] = g[H - 1][c] = "#"

    # choose number of room columns/rows (smaller rooms => longer door chains)
    ncol = rng.randint(2, max(2, min(8, (W - 2) // 7)))
    nrow = rng.randint(2, max(2, min(8, (H - 2) // 7)))

    # vertical wall column positions (between rooms), horizontal wall rows
    def split(lo, hi, n):
        # produce n interior partition lines strictly inside (lo,hi)
        if n <= 0:
            return []
        span = hi - lo
        if span < (n + 1) * 4:
            n = max(1, span // 4 - 1)
        cuts = sorted(rng.sample(range(lo + 3, hi - 2), min(n, max(1, hi - lo - 5)))) if hi - lo - 5 > 0 else []
        # enforce spacing
        out = []
        last = lo
        for x in cuts:
            if x - last >= 4 and hi - x >= 4:
                out.append(x)
                last = x
        return out

    vlines = split(0, W - 1, ncol - 1)  # wall columns
    hlines = split(0, H - 1, nrow - 1)  # wall rows
    for c in vlines:
        for r in range(H):
            g[r][c] = "#"
    for r in hlines:
        for c in range(W):
            g[r][c] = "#"

    # room boundaries
    col_edges = [0] + vlines + [W - 1]
    row_edges = [0] + hlines + [H - 1]
    rooms = []
    for i in range(len(row_edges) - 1):
        for j in range(len(col_edges) - 1):
            r0 = row_edges[i] + 1
            r1 = row_edges[i + 1] - 1
            c0 = col_edges[j] + 1
            c1 = col_edges[j + 1] - 1
            if r1 >= r0 and c1 >= c0:
                rooms.append((r0, r1, c0, c1))

    # carve doorways: for each adjacent pair of rooms sharing a wall line,
    # open exactly one cell. We do it on the wall grid lines.
    # Vertical walls (columns in vlines): open between vertically-aligned rooms.
    for c in vlines:
        # find runs of floor on both sides over rows
        r = 1
        while r < H - 1:
            if g[r][c - 1] == "." and g[r][c + 1] == ".":
                # candidate doorway region; collect contiguous run
                start = r
                while r < H - 1 and g[r][c - 1] == "." and g[r][c + 1] == ".":
                    r += 1
                end = r - 1
                if end - start >= 1:
                    dr = rng.randint(start + 1, end - 1) if end - start >= 2 else (start + end) // 2
                    g[dr][c] = "."
                elif end == start:
                    g[start][c] = "."
            else:
                r += 1
    for rr in hlines:
        c = 1
        while c < W - 1:
            if g[rr - 1][c] == "." and g[rr + 1][c] == ".":
                start = c
                while c < W - 1 and g[rr - 1][c] == "." and g[rr + 1][c] == ".":
                    c += 1
                end = c - 1
                if end - start >= 1:
                    dc = rng.randint(start + 1, end - 1) if end - start >= 2 else (start + end) // 2
                    g[rr][dc] = "."
                elif end == start:
                    g[rr][start] = "."
            else:
                c += 1

    return g, rooms


def plant(g, H, W, rng, nsrc):
    """Place nsrc lasers and plant beams (mirrors+cats).

    Each laser snakes through the rooms via planted turn-mirrors, dropping cats
    along the way. deep[(r,c)] records how many planted mirrors the beam had
    turned through before reaching that cat (its routing depth). Returns
    (placed_mirrors, srcs, deep).
    """
    placed = []
    srcs = []
    B = W * H * 2
    deep = {}  # cat cell -> number of planted mirrors traversed before it

    def floor_cells():
        return [(r, c) for r in range(H) for c in range(W) if g[r][c] == "."]

    # Strategy: keep mirrors RARE (few turns) but cats DENSE along beams. This
    # produces cats >> L. Each laser snakes a little, dropping many cats. The
    # solver must choose which subset of cats to light with the tiny L budget;
    # when cats live in different rooms reached by different turns, it cannot
    # share mirrors and coverage stays low.
    # mix regimes across seeds: sometimes sparse cats behind several turns
    # (forces per-cat routing), sometimes denser cat corridors.
    regime = rng.random()
    if regime < 0.5:
        p_mirror = rng.uniform(0.10, 0.22)
        p_cat = rng.uniform(0.06, 0.16)
        min_turns_for_cat = rng.choice([1, 2, 2, 3])
    else:
        p_mirror = rng.uniform(0.05, 0.14)
        p_cat = rng.uniform(0.20, 0.45)
        min_turns_for_cat = rng.choice([0, 1, 1, 2])
    for _ in range(nsrc):
        fl = floor_cells()
        if not fl:
            break
        sr, sc = rng.choice(fl)
        d = rng.choice(TURNS)
        g[sr][sc] = d
        srcs.append((sr, sc, d))
        dr, dc = DIRS[d]
        r, c = sr + dr, sc + dc
        step = 0
        mirrors_on_path = 0
        while step < B:
            if not (0 <= r < H and 0 <= c < W) or g[r][c] == "#":
                break
            if g[r][c] == ".":
                roll = rng.random()
                if roll < p_mirror:
                    options = []
                    for (ndr, ndc) in DIRS.values():
                        if (ndr, ndc) == (dr, dc) or (ndr, ndc) == (-dr, -dc):
                            continue
                        mt = mirror_for(dr, dc, ndr, ndc)
                        if mt is not None:
                            options.append((mt, ndr, ndc))
                    if options:
                        mt, ndr, ndc = rng.choice(options)
                        g[r][c] = mt
                        placed.append((r, c))
                        mirrors_on_path += 1
                        dr, dc = ndr, ndc
                elif roll < p_mirror + p_cat and mirrors_on_path >= min_turns_for_cat:
                    g[r][c] = "O"
                    deep[(r, c)] = mirrors_on_path
            r += dr
            c += dc
            step += 1
    return placed, srcs, deep


def gen(seed, H, W, slack=0):
    rng = random.Random(seed)
    g, rooms = build_rooms(H, W, rng)
    if len(rooms) < 2:
        return None
    # bias toward many lasers: the reference solver struggles to coordinate the
    # routing of many beams under a tight shared mirror budget.
    nsrc = rng.choice([6, 7, 8, 8, 9, 9, 10, 10, 10])
    placed, srcs, deep = plant(g, H, W, rng, nsrc)
    if len(placed) < 1 or len(srcs) < 1:
        return None

    # --- 1. Identify straight-shot cats: cats reachable with NO mirror at all.
    # Re-simulate the lasers on a board where ALL planted mirrors are removed.
    # Any cat hit by such a bare beam is "free" for the solver and must go.
    bare = [row[:] for row in g]
    for (r, c) in placed:
        bare[r][c] = "."
    free_lit = lit_cats(bare, H, W, srcs)  # cats lightable with 0 mirrors
    for (r, c) in free_lit:
        if g[r][c] == "O":
            g[r][c] = "."  # remove free cats from the real board too

    # --- 2. With planted mirrors present, find which (remaining) cats are lit.
    lit = lit_cats(g, H, W, srcs)
    for r in range(H):
        for c in range(W):
            if g[r][c] == "O" and (r, c) not in lit:
                g[r][c] = "."
    if sum(row.count("O") for row in g) < 3:
        return None

    # --- 3. Trim unused planted mirrors: keep only mirrors whose removal would
    # drop a kept cat. This shrinks L to the true planted-solution size so the
    # budget is genuinely tight, while feasibility (all kept cats lit) holds.
    kept_mirrors = []
    cur_lit = lit_cats(g, H, W, srcs)
    needed = set((r, c) for r in range(H) for c in range(W) if g[r][c] == "O")
    for (r, c) in placed:
        if g[r][c] not in "/\\":
            continue
        saved = g[r][c]
        g[r][c] = "."
        still = lit_cats(g, H, W, srcs)
        if needed.issubset(still):
            # mirror not needed for any kept cat; leave it removed
            pass
        else:
            g[r][c] = saved
            kept_mirrors.append((r, c))

    # final feasibility check: all kept cats lit by kept mirrors
    final_lit = lit_cats(g, H, W, srcs)
    if not needed.issubset(final_lit):
        return None
    # erase mirrors from the published board
    for (r, c) in kept_mirrors:
        g[r][c] = "."
    L = len(kept_mirrors) + slack
    if L < 1:
        return None
    ncats = sum(row.count("O") for row in g)
    if ncats < 3:
        return None
    txt = "\n".join([f"{W} {H} {L}"] + ["".join(x) for x in g]) + "\n"
    return txt, ncats, len(srcs), L


def run_solver(txt, timeout_s=12):
    try:
        p = subprocess.run([SOLVER], input=txt, capture_output=True,
                           text=True, timeout=timeout_s)
        return p.stdout
    except subprocess.TimeoutExpired:
        return None
    except Exception:
        return None


def coverage(in_txt, out_txt):
    """Judge-faithful coverage from solver output. Returns (lit, total)."""
    DZ = {"A": (0, -1), "V": (0, 1), "<": (-1, 0), ">": (1, 0)}
    ilines = in_txt.split("\n")
    olines = out_txt.split("\n")
    W, H, M = map(int, ilines[0].split())
    ib = [list(ilines[1 + i]) for i in range(H)]
    if len(olines) < 1 + H or not olines[0].strip():
        return 0, sum(r.count("O") for r in ib)
    try:
        ob = [list(olines[1 + i]) for i in range(H)]
    except IndexError:
        return 0, sum(r.count("O") for r in ib)
    # validate dims
    if any(len(row) < W for row in ob[:H]):
        return 0, sum(r.count("O") for r in ib)
    tot = sum(r.count("O") for r in ib)
    B = W * H * 2

    def trace(b, x, y, dx, dy):
        s = 0
        while 0 <= y < H and 0 <= x < W:
            ch = b[y][x]
            if ch == "O":
                b[y][x] = "X"
            elif ch == "#":
                break
            elif ch == "/":
                dx, dy = -dy, -dx
            elif ch == "\\":
                dx, dy = dy, dx
            x += dx
            y += dy
            s += 1
            if s > B:
                return
    for y in range(H):
        for x in range(W):
            if ob[y][x] in DZ:
                dx, dy = DZ[ob[y][x]]
                trace(ob, x, y, dx, dy)
    lit = tot - sum(r.count("O") for r in ob)
    return lit, tot


def main():
    os.makedirs(HUNT, exist_ok=True)
    rng = random.Random(20260604)
    saved = []
    covs = []
    t0 = time.time()
    budget_seeds = 600
    budget_secs = 200
    # favor medium/large boards where multi-laser routing under a tight budget
    # has been most effective at confusing the reference solver.
    sizes = [(50, 50), (50, 80), (80, 50), (60, 60), (70, 70),
             (80, 80), (40, 100), (100, 40), (90, 90), (100, 100),
             (50, 80), (80, 50), (60, 90), (90, 60)]
    attempts = 0
    for i in range(budget_seeds):
        if time.time() - t0 > budget_secs:
            break
        seed = rng.randint(1, 10**9)
        H, W = rng.choice(sizes)
        slack = 0  # tight budget makes the solver work hardest
        res = gen(seed, H, W, slack)
        if res is None:
            continue
        txt, ncats, nlasers, L = res
        if ncats < 3:
            continue
        attempts += 1
        out = run_solver(txt)
        if out is None:
            # timeout -> still interesting but cannot measure; skip
            continue
        lit, tot = coverage(txt, out)
        if tot == 0:
            continue
        cov = lit / tot
        covs.append((cov, seed, H, W, L, ncats, nlasers))
        if cov < 0.5:
            fn = os.path.join(HUNT, f"rooms_{seed}.in")
            with open(fn, "w") as f:
                f.write(txt)
            saved.append((fn, cov, H, W, L, ncats, nlasers, lit, tot))

    # report
    print(f"# attempts(solved-measured)={attempts}  saved(<0.5)={len(saved)}  elapsed={time.time()-t0:.1f}s")
    if covs:
        cs = sorted(c[0] for c in covs)
        n = len(cs)
        print(f"# coverage min={cs[0]:.3f} median={cs[n//2]:.3f} max={cs[-1]:.3f} count={n}")
        below = [c for c in cs if c < 0.5]
        print(f"# below0.5={len(below)}  below0.3={sum(1 for c in cs if c<0.3)}")
    for (fn, cov, H, W, L, ncats, nlasers, lit, tot) in sorted(saved, key=lambda x: x[1])[:15]:
        print(f"SAVED {os.path.basename(fn)} W={W} H={H} L={L} cats={ncats} lasers={nlasers} cov={cov:.3f} ({lit}/{tot})")
    # also report lowest-coverage non-saved if none saved
    if not saved and covs:
        covs.sort()
        for (cov, seed, H, W, L, ncats, nlasers) in covs[:10]:
            print(f"LOW seed={seed} W={W} H={H} L={L} cats={ncats} lasers={nlasers} cov={cov:.3f}")


if __name__ == "__main__":
    if len(sys.argv) >= 3 and sys.argv[1] == "--one":
        seed = int(sys.argv[2])
        H = int(sys.argv[3]) if len(sys.argv) > 3 else 40
        W = int(sys.argv[4]) if len(sys.argv) > 4 else 40
        res = gen(seed, H, W, 0)
        if res:
            sys.stdout.write(res[0])
    else:
        main()
