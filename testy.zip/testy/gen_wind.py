#!/usr/bin/env python3
"""Non-serpentine DENSE winding boards for Kotron (Checkpoint D).

Plant-and-erase: we DRIVE a single (or few) laser beam(s) along a chosen
NON-serpentine path (spiral / comb / irregular-stride / skip-gap), placing the
mirror needed at each turn, marking passed cells as cats 'O'. Then we ERASE all
planted mirrors. L = #mirrors planted (+ optional slack). Finally we RECOMPUTE
the lit set with the bare laser(s) and drop any 'O' not actually lit -> the board
is EXACTLY feasible by definition (re-inserting the planted mirrors lights 100%).

Coordinate convention matches judge / litcheck.py exactly:
    cell indexed (r=row, c=col); direction as (dr, dc).
    A (North) = (-1, 0), V (South) = (1, 0), < (West) = (0, -1), > (East) = (0, 1)
Reflections (in (dr,dc)):
    '/'  : (dr,dc) -> (-dc, -dr)
    '\\' : (dr,dc) -> ( dc,  dr)

Usage:
    gen_wind.py <mode> <H> <W> [--slack S] [--seed N] [--stride-min a] [--stride-max b]
                                [--gap G] [--lasers K]
modes: spiral comb estride skip combskip spiralmulti

The path engine: we give a list of TURN waypoints. Between turns the beam goes
straight (lighting every cell). At a turn cell we place the mirror mapping the
incoming dir to the outgoing dir. Straight pass-through cells stay '.' carrying
the beam (they become 'O' cats). The mirror cells, after erase, are '.' too and
ARE on the path so they are lit when re-inserted? No: after erase a mirror cell
is '.', and the bare beam goes straight through it -- so a turn cell is NOT lit
by the bare beam. We therefore do NOT mark turn cells as 'O'. The recompute step
also enforces this.
"""
import sys
import random

DIRS = {"A": (-1, 0), "V": (1, 0), "<": (0, -1), ">": (0, 1)}
SOLFILE = None


def refl(mt, dr, dc):
    return (-dc, -dr) if mt == "/" else (dc, dr)


def mirror_for(din, dout):
    """Return mirror char ('/' or '\\') that turns incoming dir din into dout,
    or None if no single mirror does it (straight or reversal)."""
    for mt in ("/", "\\"):
        if refl(mt, din[0], din[1]) == dout:
            return mt
    return None


def lit_cats(g, H, W, srcs):
    """Judge-faithful simulation, bound = W*H*2."""
    lit = set()
    B = W * H * 2
    for (sr, sc, d) in srcs:
        dr, dc = DIRS[d]
        r, c = sr, sc
        step = 0
        while 0 <= r < H and 0 <= c < W:
            ch = g[r][c]
            if ch == "#":
                break
            if ch == "O":
                lit.add((r, c))
            elif ch == "/":
                dr, dc = refl("/", dr, dc)
            elif ch == "\\":
                dr, dc = refl("\\", dr, dc)
            r += dr
            c += dc
            step += 1
            if step > B:
                break
    return lit


class Planter:
    """Drives a beam along an explicit turn-sequence, planting mirrors+cats."""

    def __init__(self, g, H, W):
        self.g = g
        self.H = H
        self.W = W
        self.mirrors = []  # (r,c) cells where we planted a mirror
        self.cats = set()  # cells we want lit (straight pass-through)

    def inb(self, r, c):
        return 0 <= r < self.H and 0 <= c < self.W

    def free(self, r, c):
        return self.inb(r, c) and self.g[r][c] == "."

    def run(self, start, sdir, turns):
        """start=(r,c) of laser cell; sdir char; turns=list of (r,c) where the
        beam must turn, each paired with the NEW direction char after the turn.
        Format of turns: list of ((r,c), newdir_char).
        Beam starts at the cell AFTER the laser, moving sdir. At each listed
        turn cell we place the appropriate mirror. We light every straight cell
        passed (that is '.'). Returns True if planting succeeded fully."""
        g = self.g
        r, c = start
        d = sdir
        if not self.inb(r, c):
            return False
        g[r][c] = d  # laser marker
        dr, dc = DIRS[d]
        turn_map = {pos: nd for pos, nd in turns}
        r += dr
        c += dc
        steps = 0
        cap = self.W * self.H * 2 - 1
        while self.inb(r, c) and steps < cap:
            steps += 1
            if (r, c) in turn_map:
                nd = turn_map[(r, c)]
                mt = mirror_for((dr, dc), DIRS[nd])
                if mt is None:
                    return False  # impossible turn (straight or 180)
                if g[r][c] != ".":
                    return False  # would clobber something
                g[r][c] = mt
                self.mirrors.append((r, c))
                dr, dc = DIRS[nd]
                r += dr
                c += dc
                continue
            # straight cell: must be free to carry beam & be a cat
            if g[r][c] == "#":
                return False
            if g[r][c] == ".":
                self.cats.add((r, c))
            # if it's already a planted mirror cell from earlier crossing, beam
            # would turn there -- our paths avoid revisiting mirror cells.
            r += dr
            c += dc
        return True


# ---------------------------------------------------------------------------
# Path builders: each returns (start, sdir, turns) for a single laser, or a
# list of such for multi-laser. Turns are (cell, newdir).
# ---------------------------------------------------------------------------

def path_spiral(H, W, margin=0):
    """Inward rectangular spiral. Beam enters top-left going East, spirals in.
    Turns at each corner. Uses '>' laser at (0,0)? We start laser just outside.
    We keep a 1-cell frame so the laser & turns are inside the grid.
    Returns single-laser triple."""
    top, bot, left, right = 0, H - 1, 0, W - 1
    # laser at (0,0) firing East; first turn at (0, right)
    start = (0, 1)
    sdir = ">"
    turns = []
    # We walk the spiral border, turning at corners, shrinking each lap.
    # State: position conceptually at corner cells.
    d = ">"
    # corner sequence
    while left <= right and top <= bot:
        if d == ">":
            # going east along row=top from left+1.. to right; turn down at (top,right)
            if top + 1 > bot:
                break
            turns.append(((top, right), "V"))
            d = "V"
            top += 1
        elif d == "V":
            if right - 1 < left:
                break
            turns.append(((bot, right), "<"))
            d = "<"
            right -= 1
        elif d == "<":
            if bot - 1 < top:
                break
            turns.append(((bot, left), "A"))
            d = "A"
            bot -= 1
        elif d == "A":
            if left + 1 > right:
                break
            turns.append(((top, left), ">"))
            d = ">"
            left += 1
    return start, sdir, turns


def path_comb(H, W, teeth_gap=3):
    """E / comb shape: a vertical spine on the left, horizontal teeth combing
    right then returning. The beam goes down the spine and at each tooth row
    darts right to the wall and back? It can't come back through the same row
    (180). Instead: spine on left going DOWN; at tooth rows turn East, run to
    right edge, turn DOWN one, turn West, run back to spine+1, turn DOWN one,
    continue spine. This makes a comb whose path is a sequence of stubby
    serpentine teeth but with a long vertical 'spine' connector that is NOT a
    clean every-row serpentine (stride alternates spine vs sweep)."""
    start = (0, 0)
    sdir = "V"  # fire South down the spine (laser at (0,0))
    # Actually laser at top-left firing South. Spine column = 0.
    turns = []
    spine = 0
    r = 0
    going = "V"
    tooth = 0
    # We descend the spine; every teeth_gap rows we shoot a tooth east.
    rr = 0
    rows = []
    r2 = 0
    while r2 < H:
        rows.append(r2)
        r2 += teeth_gap
    # Build: from top, for each tooth row, dart east to col W-1, drop 1, west
    # back to col 1, drop 1, continue down spine to next tooth row.
    cur = 0
    east_edge = W - 1
    spine_col = 0
    last_dir = "V"
    for i, tr in enumerate(rows):
        if tr + 2 >= H:
            break
        # at (tr, spine_col): turn East
        turns.append(((tr, spine_col), ">"))
        # run east to (tr, east_edge): turn South
        turns.append(((tr, east_edge), "V"))
        # drop to (tr+1, east_edge): turn West
        turns.append(((tr + 1, east_edge), "<"))
        # run west to (tr+1, spine_col+1): turn South (back near spine)
        turns.append(((tr + 1, spine_col + 1), "V"))
        # we are now at column spine_col+1 going down; next tooth needs us at
        # spine_col. Shift left by turning... at next tooth row turn handled by
        # starting that tooth's East turn. But we're at col spine_col+1 not
        # spine_col. Adjust: keep spine at spine_col+1 won't matter; but teeth
        # 'East' turn expects current col. Let's instead keep beam on col
        # spine_col+1 as the descending spine and shoot teeth from there.
        spine_col = spine_col  # keep East turns from col we are on
    return start, sdir, turns


def path_comb2(H, W, teeth_gap=3):
    """Comb / E-shape: descend a fixed spine column; at each tooth row dart East
    to the wall, drop one row, run West back to spine+1, drop one row back onto
    the spine, continue descending. The spine sits at column 1; teeth reach the
    right wall. The down-jog uses col spine and spine+1 so we never revisit a
    cell. Laser fires South from (0, spine); first tooth at row 1."""
    spine = 0
    start = (0, spine)
    sdir = "V"
    turns = []
    east = W - 1
    r = 1
    while r + 2 < H:
        # at (r, spine): turn East
        turns.append(((r, spine), ">"))
        # (r, east): turn South
        turns.append(((r, east), "V"))
        # (r+1, east): turn West
        turns.append(((r + 1, east), "<"))
        # run West back to (r+1, spine+1): turn South (jog one col right of spine)
        turns.append(((r + 1, spine + 1), "V"))
        # (r+2, spine+1): turn West to get back onto spine column
        turns.append(((r + 2, spine + 1), "<"))
        # (r+2, spine): turn South -> back on spine, descend to next tooth
        turns.append(((r + 2, spine), "V"))
        r += teeth_gap
    return start, sdir, turns


def path_estride(H, W, rng, smin=2, smax=4):
    """Irregular-stride serpentine: sweep a row, U-turn down a RANDOM number of
    rows (between smin and smax) before sweeping back. The varying stride is
    what a fixed-stride serp builder cannot match."""
    start = (0, 0)
    sdir = ">"
    turns = []
    r = 0
    east = W - 1
    west = 0
    going_east = True
    while True:
        stride = rng.randint(smin, smax)
        nr = r + stride
        if nr >= H - 1:
            break
        if going_east:
            # turn down at east edge
            turns.append(((r, east), "V"))
            # descend stride rows then turn West
            turns.append(((nr, east), "<"))
            going_east = False
        else:
            turns.append(((r, west), "V"))
            turns.append(((nr, west), ">"))
            going_east = True
        r = nr
    return start, sdir, turns


def path_skip(H, W, rng, gap=2):
    """Skip-gap serpentine: a serpentine whose sweep rows contain rectangular
    NOTCHES -- the beam dips DOWN by 2, runs a short distance, and comes back
    UP to the sweep row. This makes the lit cats NON-contiguous along the
    nominal row (a row-filling serpentine builder over-claims the notch gap).
    Notches are placed on a fixed, well-spaced grid so segments never overlap.

    East sweep notch at column bc (width 3):
        (r,bc):V  (r+2,bc):>  (r+2,bc+3):A  (r,bc+3):>
    The cells (r, bc+1), (r, bc+2) are NOT on the path -> a 2-cell gap.
    """
    start = (0, 0)
    sdir = ">"
    turns = []
    east = W - 1
    west = 0
    going_east = True
    band = 4
    notch_w = 3
    r = 0
    spacing = max(8, gap * 4)
    while r + band < H - 1:
        # notch anchor columns, spaced every `spacing`, leaving margins
        anchors = list(range(4, W - notch_w - 4, spacing))
        if going_east:
            for bc in anchors:
                turns.append(((r, bc), "V"))
                turns.append(((r + 2, bc), ">"))
                turns.append(((r + 2, bc + notch_w), "A"))
                turns.append(((r, bc + notch_w), ">"))
            turns.append(((r, east), "V"))
            turns.append(((r + band, east), "<"))
            going_east = False
        else:
            for bc in reversed(anchors):
                # mirror the notch when sweeping West
                turns.append(((r, bc + notch_w), "V"))
                turns.append(((r + 2, bc + notch_w), "<"))
                turns.append(((r + 2, bc), "A"))
                turns.append(((r, bc), "<"))
            turns.append(((r, west), "V"))
            turns.append(((r + band, west), ">"))
            going_east = True
        r += band
    return start, sdir, turns


def build(mode, H, W, rng, smin, smax, gap):
    if mode == "spiral":
        return [path_spiral(H, W)]
    if mode == "comb":
        return [path_comb2(H, W, teeth_gap=max(3, gap + 1))]
    if mode == "estride":
        return [path_estride(H, W, rng, smin, smax)]
    if mode == "skip":
        return [path_skip(H, W, rng, gap)]
    if mode == "combskip":
        # comb on top half, irregular stride bottom half via 2 lasers
        return None  # handled specially below
    raise SystemExit(f"unknown mode {mode}")


def main():
    if len(sys.argv) < 4:
        print(__doc__)
        return
    mode = sys.argv[1]
    H = int(sys.argv[2])
    W = int(sys.argv[3])
    slack = 0
    seed = 1
    smin, smax = 2, 4
    gap = 2
    global SOLFILE
    SOLFILE = None
    a = sys.argv[4:]
    for i, x in enumerate(a):
        if x == "--slack":
            slack = int(a[i + 1])
        elif x == "--seed":
            seed = int(a[i + 1])
        elif x == "--stride-min":
            smin = int(a[i + 1])
        elif x == "--stride-max":
            smax = int(a[i + 1])
        elif x == "--gap":
            gap = int(a[i + 1])
        elif x == "--solfile":
            SOLFILE = a[i + 1]
    rng = random.Random(seed)
    g = [["." for _ in range(W)] for _ in range(H)]
    paths = build(mode, H, W, rng, smin, smax, gap)
    P = Planter(g, H, W)
    srcs = []
    ok = True
    for (start, sdir, turns) in paths:
        if not P.run(start, sdir, turns):
            ok = False
        srcs.append((start[0], start[1], sdir))
    if not ok:
        sys.stderr.write("WARN: planting hit a conflict; board may be partial\n")
    # Mark intended cats as 'O' (only cells that are still '.', i.e. not mirrors
    # or laser markers). The mirrors are STILL in place.
    for (r, c) in P.cats:
        if g[r][c] == ".":
            g[r][c] = "O"
    # Recompute lit set WITH mirrors in place (this is the planted solution).
    # Drop any 'O' not actually lit by the planted beam -> exact feasibility.
    lit = lit_cats(g, H, W, srcs)
    dropped = 0
    for r in range(H):
        for c in range(W):
            if g[r][c] == "O" and (r, c) not in lit:
                g[r][c] = "."
                dropped += 1
    # Emit the SOLUTION board (mirrors in place) for feasibility re-check.
    solboard = "\n".join([f"{W} {H} {len(P.mirrors) + slack}"]
                         + ["".join(x) for x in g]) + "\n"
    # Now ERASE planted mirrors to produce the test input.
    for (r, c) in P.mirrors:
        if g[r][c] in "/\\":
            g[r][c] = "."
    L = len(P.mirrors) + slack
    cats = sum(row.count("O") for row in g)
    if SOLFILE:
        with open(SOLFILE, "w") as fh:
            fh.write(solboard)
    sys.stderr.write(
        f"mode={mode} H={H} W={W} L={L} mirrors={len(P.mirrors)} cats={cats} "
        f"dropped={dropped} lasers={len(srcs)}\n"
    )
    out = "\n".join([f"{W} {H} {L}"] + ["".join(x) for x in g]) + "\n"
    sys.stdout.write(out)


if __name__ == "__main__":
    main()
