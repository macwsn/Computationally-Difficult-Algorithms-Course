#!/usr/bin/env python3
"""Hunt for HARD wall-heavy / maze Checkpoint D instances where the reference
solver gets LOW coverage (<0.5). Feasibility guaranteed by the planting method
(adapted from gen_chd.py): build wall-heavy terrain, place lasers, trace each
beam planting mirrors (turns) + cats along the path -> that mirror layout IS a
valid solution. We re-simulate the planted solution to keep only truly-lit cats,
verify feasibility, then erase mirrors and set L = #planted mirrors.

Structural focus: heavy walls / mazes (carved maze, cave high-fill, dense walls
30-50%) with long winding serpentines so beams must snake through narrow passages.

Run: uv run python tests_chd/gen_hunt_maze.py
"""
import os
import random
import statistics
import subprocess
import sys
import time

HERE = os.path.dirname(os.path.abspath(__file__))
HUNT = os.path.join(HERE, "hunt")
SOLVER = "/tmp/sol8ref"
SUB_TIMEOUT = 12.0
WALL_CLOCK_BUDGET = 215.0  # ~3.5 minutes (cave solves hit ~4s internal budget)
MAX_SEEDS = 400

DIRS = {"A": (-1, 0), "V": (1, 0), "<": (0, -1), ">": (0, 1)}


def refl(mt, dr, dc):
    return (-dc, -dr) if mt == "/" else (dc, dr)


def lit_cats(g, H, W, srcs):
    """Judge-convention simulation: step bound = W*H*2."""
    lit = set()
    B = W * H * 2
    for (sr, sc, d) in srcs:
        dr, dc = DIRS[d]
        r, c = sr, sc
        step = 0
        while True:
            if not (0 <= r < H and 0 <= c < W):
                break
            ch = g[r][c]
            if ch == "#":
                break
            if ch == "O":
                lit.add((r, c))
            elif ch == "/":
                dr, dc = refl("/", dr, dc)
            elif ch == "\\":
                dr, dc = refl("\\", dr, dc)
            r += dr
            c += dc
            step += 1
            if step > B:
                break
    return lit


def terrain(mode, H, W, rng):
    if mode == "maze":
        # carved recursive-backtracker maze: dense walls + narrow passages
        g = [["#" for _ in range(W)] for _ in range(H)]

        def carve(r, c):
            stack = [(r, c)]
            g[r][c] = "."
            while stack:
                r, c = stack[-1]
                dirs = [(-2, 0), (2, 0), (0, -2), (0, 2)]
                rng.shuffle(dirs)
                advanced = False
                for dr, dc in dirs:
                    nr, nc = r + dr, c + dc
                    if 0 < nr < H and 0 < nc < W and g[nr][nc] == "#":
                        g[r + dr // 2][c + dc // 2] = "."
                        g[nr][nc] = "."
                        stack.append((nr, nc))
                        advanced = True
                        break
                if not advanced:
                    stack.pop()
        carve(1, 1)
        return g
    if mode in ("dense30", "dense40", "dense50"):
        p = {"dense30": 0.30, "dense40": 0.40, "dense50": 0.50}[mode]
        return [["#" if rng.random() < p else "." for _ in range(W)] for _ in range(H)]
    if mode in ("cave", "cave_high"):
        fill = 0.45 if mode == "cave" else 0.52
        g = [["#" if rng.random() < fill else "." for _ in range(W)] for _ in range(H)]
        for _ in range(4):
            ng = [row[:] for row in g]
            for r in range(H):
                for c in range(W):
                    w = sum(g[(r + dr) % H][(c + dc) % W] == "#"
                            for dr in (-1, 0, 1) for dc in (-1, 0, 1))
                    ng[r][c] = "#" if w >= 5 else "."
            g = ng
        return g
    return [["." for _ in range(W)] for _ in range(H)]


def mirror_for_turn(dr, dc, ndr, ndc):
    """Return mirror type that turns beam (dr,dc) -> (ndr,ndc), or None."""
    for mt in ("/", "\\"):
        if refl(mt, dr, dc) == (ndr, ndc):
            return mt
    return None


def gen(seed, mode, H, W, nsrc, mirror_p, cat_p):
    """Plant a long winding solution that FOLLOWS corridors through walls.

    For each laser we walk the beam. On free cells we may drop a cat. When the
    cell ahead is blocked (wall/edge) but a perpendicular cell is open, we plant
    the correct mirror to TURN the beam into that corridor -- producing long
    serpentines that snake through the maze. We also sometimes plant a turn even
    when straight is possible (mirror_p) to lengthen/wind the path. This mirror
    layout is a valid solution; we erase it and set L = #planted mirrors.
    """
    rng = random.Random(seed)
    g = terrain(mode, H, W, rng)
    placed = []
    total_m = 0
    maxm = max(H, W) * 4  # allow long serpentines
    srcs = []
    B = W * H * 2

    def free():
        return [(r, c) for r in range(H) for c in range(W) if g[r][c] == "."]

    def is_open(r, c):
        return 0 <= r < H and 0 <= c < W and g[r][c] == "."

    fl = free()
    if len(fl) < 20:
        return None
    for _ in range(nsrc):
        fl = free()
        if not fl:
            break
        sr, sc = rng.choice(fl)
        d = rng.choice("AV<>")
        dr, dc = DIRS[d]
        g[sr][sc] = d
        srcs.append((sr, sc, d))
        r, c = sr + dr, sc + dc
        step = 0
        while step < B:
            if not (0 <= r < H and 0 <= c < W) or g[r][c] == "#":
                break
            if g[r][c] == ".":
                ahead = is_open(r + dr, c + dc)
                # perpendicular open directions (corridor turns)
                perp = []
                for ndr, ndc in ((-1, 0), (1, 0), (0, -1), (0, 1)):
                    if (ndr, ndc) == (dr, dc) or (ndr, ndc) == (-dr, -dc):
                        continue
                    if is_open(r + ndr, c + ndc):
                        mt = mirror_for_turn(dr, dc, ndr, ndc)
                        if mt:
                            perp.append((ndr, ndc, mt))
                roll = rng.random()
                must_turn = (not ahead) and perp
                want_turn = perp and roll < mirror_p
                if (must_turn or want_turn) and total_m < maxm:
                    ndr, ndc, mt = rng.choice(perp)
                    g[r][c] = mt
                    placed.append((r, c))
                    total_m += 1
                    dr, dc = ndr, ndc
                elif roll < mirror_p + cat_p:
                    g[r][c] = "O"
            r += dr
            c += dc
            step += 1

    if total_m < 1:
        return None
    # keep only truly-lit cats (judge convention with planted mirrors present)
    lit = lit_cats(g, H, W, srcs)
    for r in range(H):
        for c in range(W):
            if g[r][c] == "O" and (r, c) not in lit:
                g[r][c] = "."
    cats = len(lit)
    if cats < 3 or len(srcs) < 1:
        return None
    # FEASIBILITY VERIFICATION: planted mirrors must light every kept cat
    # within budget L = total_m. (They do by construction, but verify.)
    assert lit == lit_cats(g, H, W, srcs)
    # erase mirrors -> input board; feasible with L = total_m mirrors
    for (r, c) in placed:
        g[r][c] = "."
    L = total_m
    board = "\n".join([f"{W} {H} {L}"] + ["".join(x) for x in g]) + "\n"
    return board, cats, len(srcs), L


def run_solver(board):
    try:
        p = subprocess.run([SOLVER], input=board, capture_output=True,
                           text=True, timeout=SUB_TIMEOUT)
        return p.stdout
    except subprocess.TimeoutExpired:
        return None
    except Exception:
        return None


def coverage(in_board, out_board, W, H):
    """Replicate litcheck raytrace; return (lit, total)."""
    if out_board is None:
        return None
    ib = [list(line) for line in in_board.splitlines()[1:1 + H]]
    olines = out_board.splitlines()
    if not olines:
        return None
    ob = [list(line) for line in olines[1:1 + H]]
    if len(ob) < H:
        return None
    # pad rows defensively
    for r in range(H):
        if len(ob[r]) < W:
            ob[r] += ["."] * (W - len(ob[r]))
    tot = sum(row.count("O") for row in ib)
    if tot == 0:
        return None
    # litcheck uses (x,y) with dx,dy; trace lasers in output
    DZ = {"A": (0, -1), "V": (0, 1), "<": (-1, 0), ">": (1, 0)}
    B = W * H * 2

    def trace(x, y, dx, dy):
        s = 0
        while 0 <= y < H and 0 <= x < W:
            ch = ob[y][x]
            if ch == "O":
                ob[y][x] = "X"
            if ch == "#":
                break
            if ch == "/":
                dx, dy = -dy, -dx
            if ch == "\\":
                dx, dy = dy, dx
            x += dx
            y += dy
            s += 1
            if s > B:
                return

    for y in range(H):
        for x in range(W):
            if ob[y][x] in DZ:
                trace(x, y, DZ[ob[y][x]][0], DZ[ob[y][x]][1])
    lit = tot - sum(row.count("O") for row in ob)
    return lit, tot


def feasible_check(board):
    """Re-verify the saved input is feasible within its L (independent of the
    planting bookkeeping): cheap sanity that there is >=1 laser, >=3 cats, and
    L>=1. (Full feasibility is guaranteed by construction: the planted mirror
    layout lights every kept cat with exactly L mirrors.)"""
    lines = board.splitlines()
    W, H, L = map(int, lines[0].split())
    grid = lines[1:1 + H]
    cats = sum(row.count("O") for row in grid)
    lasers = sum(sum(row.count(d) for d in "AV<>") for row in grid)
    return cats >= 3 and lasers >= 1 and L >= 1


def main():
    os.makedirs(HUNT, exist_ok=True)
    rng_meta = random.Random(12345)
    # Breaking regime discovered empirically: wall-heavy cave terrain at large
    # scale with many lasers + long winding serpentines packing many cats. The
    # reference solver hits its internal ~4s budget and returns a PARTIAL layout,
    # leaving a large fraction of (deep, serpentine) cats unlit. Maze/dense terrain
    # is also probed. We bias seeds toward the hardest configs.
    modes = ["cave_high", "cave", "maze", "dense40", "dense50"]
    start = time.time()
    saved = []
    all_cov = []
    lowest = None
    tried = 0

    for seed in range(MAX_SEEDS):
        if time.time() - start > WALL_CLOCK_BUDGET:
            break
        # Bias 70% toward the cave breaking regime, rest exploratory.
        if rng_meta.random() < 0.7:
            mode = rng_meta.choice(["cave_high", "cave"])
            side = rng_meta.choice([81, 91, 99, 99])
            H = W = side
            nsrc = rng_meta.randint(6, 8)              # many lasers
            mirror_p = rng_meta.choice([0.30, 0.40, 0.45, 0.55])  # winding
            cat_p = rng_meta.choice([0.30, 0.40, 0.45, 0.55])     # many cats
        else:
            mode = rng_meta.choice(modes)
            side = rng_meta.choice([51, 61, 71, 81, 91, 99])
            H = side
            W = side if rng_meta.random() < 0.8 else rng_meta.choice([51, 71, 91])
            nsrc = rng_meta.randint(3, 8)
            mirror_p = rng_meta.choice([0.20, 0.30, 0.45, 0.60])
            cat_p = rng_meta.choice([0.10, 0.25, 0.40])
        out = gen(seed, mode, H, W, nsrc, mirror_p, cat_p)
        if out is None:
            continue
        board, cats, lasers, L = out
        if not feasible_check(board):
            continue
        tried += 1
        sol = run_solver(board)
        cov = coverage(board, sol, W, H)
        if cov is None:
            # timeout or parse failure -> treat as 0 coverage achieved (hard!)
            # but only record if solver timed out (still feasible by planting)
            if sol is None:
                cov_frac = 0.0
                all_cov.append((cov_frac, seed, W, H, L, cats, lasers, mode, 0, cats))
                fn = os.path.join(HUNT, f"maze_{seed}.in")
                with open(fn, "w") as f:
                    f.write(board)
                saved.append((fn, W, H, L, cats, lasers, cov_frac, mode, "TIMEOUT"))
                if lowest is None or cov_frac < lowest[0]:
                    lowest = (cov_frac, fn, W, H, L, cats, lasers, mode)
            continue
        lit, tot = cov
        cov_frac = lit / tot
        all_cov.append((cov_frac, seed, W, H, L, cats, lasers, mode, lit, tot))
        if lowest is None or cov_frac < lowest[0]:
            lowest = (cov_frac, os.path.join(HUNT, f"maze_{seed}.in"),
                      W, H, L, cats, lasers, mode, lit, tot)
        if cov_frac < 0.5 and cats >= 3 and lasers >= 1:
            fn = os.path.join(HUNT, f"maze_{seed}.in")
            with open(fn, "w") as f:
                f.write(board)
            saved.append((fn, W, H, L, cats, lasers, cov_frac, mode, f"{lit}/{tot}"))

    elapsed = time.time() - start
    print(f"=== HUNT DONE: tried={tried} elapsed={elapsed:.1f}s saved={len(saved)} ===")
    fracs = [x[0] for x in all_cov]
    if fracs:
        print(f"coverage over all tried: min={min(fracs):.3f} "
              f"median={statistics.median(fracs):.3f} max={max(fracs):.3f}")
        print("--- 8 lowest-coverage instances (any) ---")
        for x in sorted(all_cov)[:8]:
            print(f"  seed={x[1]} {x[2]}x{x[3]} L={x[4]} cats={x[5]} lasers={x[6]} "
                  f"cov={x[0]:.3f} ({x[8]}/{x[9]}) [{x[7]}]")
    if saved:
        bcov = [s[6] for s in saved]
        print(f"BREAKING (<0.5): n={len(saved)} min_cov={min(bcov):.3f} "
              f"median_cov={statistics.median(bcov):.3f}")
        sizes = [(s[1], s[2]) for s in saved]
        lasers = [s[5] for s in saved]
        modes_b = {}
        for s in saved:
            modes_b[s[7]] = modes_b.get(s[7], 0) + 1
        print(f"breaking modes: {modes_b}")
        print(f"breaking laser counts: min={min(lasers)} max={max(lasers)} "
              f"median={statistics.median(lasers)}")
        print(f"breaking sizes: {sorted(set(sizes))}")
        print("--- examples (file: W H L cats lasers coverage) ---")
        for s in sorted(saved, key=lambda x: x[6])[:6]:
            print(f"{os.path.basename(s[0])}: {s[1]} {s[2]} {s[3]} "
                  f"cats={s[4]} lasers={s[5]} cov={s[6]:.3f} ({s[8]}) [{s[7]}]")
    else:
        print("NO breaking cases <0.5 found.")
        if lowest:
            print(f"lowest coverage achieved: {lowest[0]:.3f} "
                  f"({lowest[2]}x{lowest[3]} L={lowest[4]} cats={lowest[5]} "
                  f"lasers={lowest[6]} mode={lowest[7]} lit={lowest[8]}/{lowest[9]})")


if __name__ == "__main__":
    main()
