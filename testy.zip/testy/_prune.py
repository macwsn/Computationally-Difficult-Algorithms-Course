import glob, os, subprocess, time, shutil
EXE = r"C:\Users\macie\Documents\GitHub\APTO-Project\test_test.exe"
DR=[-1,1,0,0]; DC=[0,0,-1,1]; RS={0:3,1:2,2:1,3:0}; RB={0:2,1:3,2:0,3:1}
BS=chr(92); SL=chr(47)
def solves(f):
    inp=open(f).read(); hdr=inp.split('\n')[0].split()
    if len(hdr)<3: return True
    W,H,L=int(hdr[0]),int(hdr[1]),int(hdr[2])
    try: out=subprocess.run([EXE],input=inp,capture_output=True,text=True,timeout=20).stdout
    except Exception: return False
    og=out.split('\n')[1:1+H]
    if len(og)<H: return False
    def cell(r,c): return og[r][c] if 0<=r<H and 0<=c<len(og[r]) else '#'
    lit=set(); las=[]; cats=0
    for r in range(H):
        for c in range(len(og[r])):
            ch=og[r][c]
            if ch=='O': cats+=1
            elif ch in 'AV<>': las.append((r,c,{'A':0,'V':1,'<':2,'>':3}[ch]))
    if cats==0: return True
    for (r,c,d) in las:
        seen=set(); rr,cc,dd=r+DR[d],c+DC[d],d; steps=0; B=W*H*2
        while 0<=rr<H and 0<=cc<W and steps<=B:
            if (rr,cc,dd) in seen: break
            seen.add((rr,cc,dd)); ch=cell(rr,cc)
            if ch=='#': break
            if ch=='O': lit.add((rr,cc))
            elif ch==SL: dd=RS[dd]
            elif ch==BS: dd=RB[dd]
            rr+=DR[dd]; cc+=DC[dd]; steps+=1
    return len(lit)==cats
files=[f.replace("\\","/") for f in sorted(glob.glob("*/*.in"))]
files=[f for f in files if not f.startswith("_removed/")]
fails=[]; npass=0; t0=time.time()
for i,f in enumerate(files):
    if solves(f): npass+=1
    else: fails.append(f)
    if (i+1)%100==0: print(f"  {i+1}/{len(files)} pass={npass} fail={len(fails)} {time.time()-t0:.0f}s", flush=True)
print(f"TOTAL {len(files)}: pass={npass} fail={len(fails)}")
moved=0
for f in fails:
    dst=os.path.join("_removed", f); os.makedirs(os.path.dirname(dst), exist_ok=True)
    try: shutil.move(f, dst); moved+=1
    except Exception as e: print("err",f,e)
import collections
print(f"moved {moved} -> _removed/ ; per dir:", dict(collections.Counter(f.split('/')[0] for f in fails)))
