#!/usr/bin/env python3
"""Hunt HARD feasible Kotron Checkpoint D instances: tight mirror budget L,
shared mirrors across cats, detours around walls. Save cases where the
reference solver achieves coverage < 0.5.

Strategies (all PLANT a solution, then erase mirrors so feasibility within L
is guaranteed; planted mirror count <= L):

  serpentine : one laser, long boustrophedon path turning at walls/edges,
               threading many cats between turns. ONE mirror routes the beam
               past several cats -> minimal solution must reuse turns.
  pockets    : cats hidden in walled pockets; reaching them needs 2-3 mirror
               detours around the wall. L set just barely enough.
  mixed      : multiple lasers, dense walls, planted serpentines per laser.

Usage:
  gen_hunt_tight.py run [nseeds] [time_budget_s]   # hunt, save breakers
  gen_hunt_tight.py --one <seed> <strat> <H> <W> [slack]  # emit one instance
"""
import os
import random
import subprocess
import sys
import time

DIRS = {"A": (-1, 0), "V": (1, 0), "<": (0, -1), ">": (0, 1)}
REF = "/tmp/sol8ref"
HUNT_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "hunt")


def refl(mt, dr, dc):
    return (-dc, -dr) if mt == "/" else (dc, dr)


def lit_cats(g, H, W, srcs):
    """Judge-consistent simulation; step bound = W*H*2 per source."""
    lit = set()
    B = W * H * 2
    for (sr, sc, d) in srcs:
        dr, dc = DIRS[d]
        r, c = sr, sc
        step = 0
        while True:
            if not (0 <= r < H and 0 <= c < W):
                break
            ch = g[r][c]
            if ch == "#":
                break
            if ch == "O":
                lit.add((r, c))
            elif ch == "/":
                dr, dc = refl("/", dr, dc)
            elif ch == "\\":
                dr, dc = refl("\\", dr, dc)
            r += dr
            c += dc
            step += 1
            if step > B:
                break
    return lit


# ----------------------------------------------------------------------------
# Planting helpers. We work on grid g (list of list of char). A "plant" routes
# a beam, dropping mirrors at chosen turn cells and cats along straights. We
# only ever write mirrors onto '.' cells, and cats onto '.' cells.
# ----------------------------------------------------------------------------

def in_b(H, W, r, c):
    return 0 <= r < H and 0 <= c < W


def plant_serpentine(g, H, W, rng, n_turns, cats_per_leg, mirror_prob_cat=0.55):
    """Place one laser and snake it across the board. At each leg we walk
    forward placing a few cats on '.', then drop a single mirror to turn 90deg.
    Returns (src, placed_mirrors, planted_cats) or None.

    Key: one mirror per turn services an entire leg of cats -> shared.
    """
    # pick a start on an edge facing inward, on a '.' cell
    free = [(r, c) for r in range(H) for c in range(W) if g[r][c] == "."]
    if not free:
        return None
    # prefer a corner-ish start for a long serpentine
    starts = [(r, c) for (r, c) in free if r in (0, 1, H - 2, H - 1) or c in (0, 1, W - 2, W - 1)]
    if not starts:
        starts = free
    sr, sc = rng.choice(starts)
    # initial direction roughly toward board interior
    if sr <= H // 2 and sc <= W // 2:
        d = rng.choice([">", "V"])
    elif sr <= H // 2:
        d = rng.choice(["<", "V"])
    elif sc <= W // 2:
        d = rng.choice([">", "A"])
    else:
        d = rng.choice(["<", "A"])

    g[sr][sc] = d
    src = (sr, sc, d)
    dr, dc = DIRS[d]
    r, c = sr + dr, sc + dc
    placed = []
    cats = []
    legs = 0
    while legs < n_turns + 1:
        # walk forward along current dir, placing cats
        leg_cells = []
        ncat = 0
        # advance until we want to turn or hit obstacle/edge
        steps_this_leg = 0
        target_leg_len = rng.randint(cats_per_leg + 2, cats_per_leg + 8)
        while True:
            if not in_b(H, W, r, c) or g[r][c] == "#":
                break
            if g[r][c] == ".":
                # place a cat sometimes
                if ncat < cats_per_leg and rng.random() < mirror_prob_cat:
                    g[r][c] = "O"
                    cats.append((r, c))
                    ncat += 1
                leg_cells.append((r, c))
            elif g[r][c] in "/\\OAV<>":
                # already occupied (a prior mirror/laser) -> beam interaction
                # would change planting; just stop this leg here to keep simple
                break
            steps_this_leg += 1
            if steps_this_leg >= target_leg_len:
                break
            r += dr
            c += dc
        # now r,c is where we want to turn (next cell). Need a '.' to drop a mirror.
        # back up to last valid free cell to place a turning mirror.
        # We place the mirror on the current straight then turn.
        if not in_b(H, W, r, c) or g[r][c] != ".":
            # can't place mirror here; try to step back to a free cell on the leg
            if leg_cells:
                r, c = leg_cells[-1]
                # remove a cat if we placed one there to free it for a mirror
                if g[r][c] == "O" and (r, c) in cats:
                    g[r][c] = "."
                    cats.remove((r, c))
            else:
                break
        if g[r][c] != ".":
            break
        # choose a mirror that turns us 90 degrees into a new in-board direction
        mt = rng.choice("/\\")
        ndr, ndc = refl(mt, dr, dc)
        # if the new direction immediately leaves board or hits wall, try other
        if not in_b(H, W, r + ndr, c + ndc) or g[r + ndr][c + ndc] == "#":
            mt = "\\" if mt == "/" else "/"
            ndr, ndc = refl(mt, dr, dc)
            if not in_b(H, W, r + ndr, c + ndc) or g[r + ndr][c + ndc] == "#":
                break
        g[r][c] = mt
        placed.append((r, c))
        dr, dc = ndr, ndc
        r, c = r + dr, c + dc
        legs += 1
    return src, placed, cats


def plant_boustrophedon(g, H, W, rng, row_step=2, cat_fill=0.9, margin=1):
    """Dense full-board serpentine (boustrophedon) from ONE laser. The beam
    sweeps row by row, every `row_step` rows, turning with a single mirror at
    each end. Cats are packed densely along each horizontal leg. This pushes
    the *number of cats threaded by one beam* far above the beam-search
    per-cat threshold (~88 on 100x100) while keeping the mirror count low
    (2 mirrors per row-turn) -> brutally tight sharing.

    Returns (src, placed_mirrors, cats) or None.
    """
    # rows we sweep
    rows = list(range(margin, H - margin, row_step))
    if len(rows) < 3:
        return None
    # all sweep cells must be walkable; force them clear
    for r in rows:
        for c in range(margin, W - margin):
            if g[r][c] == "#":
                g[r][c] = "."
    # vertical connectors at the two ends must be clear too
    for r in range(margin, H - margin):
        for cc in (margin, W - 1 - margin):
            if g[r][cc] == "#":
                g[r][cc] = "."

    placed = []
    cats = []
    # laser enters at left of first row going right
    r0 = rows[0]
    sr, sc = r0, margin
    g[sr][sc] = ">"
    src = (sr, sc, ">")
    dr, dc = 0, 1
    r, c = sr, sc + 1
    going_right = True
    ri = 0
    while True:
        # walk along the row placing cats until the turn column
        end_c = (W - 1 - margin) if going_right else margin
        step = 1 if going_right else -1
        cc = c
        while 0 <= cc < W and cc != end_c:
            if g[r][cc] == ".":
                if rng.random() < cat_fill:
                    g[r][cc] = "O"
                    cats.append((r, cc))
            cc += step
        # at end_c we need to drop a mirror to go DOWN, then another to resume
        # horizontal in the opposite direction on the next swept row.
        if ri + 1 >= len(rows):
            break
        nr = rows[ri + 1]
        # mirror1 at (r, end_c): turn horizontal->down
        if going_right:
            # moving right (0,1) -> want down (1,0): '\' gives (dc,dr)=(1,0) YES
            m1 = "\\"
        else:
            # moving left (0,-1) -> want down (1,0): '/' gives (-dc,-dr)=(1,0) YES
            m1 = "/"
        if g[r][end_c] != ".":
            break
        g[r][end_c] = m1
        placed.append((r, end_c))
        # beam goes down from (r,end_c) to (nr,end_c); ensure clear (it is)
        # mirror2 at (nr, end_c): turn down->horizontal(opposite)
        if going_right:
            # moving down (1,0) -> want left (0,-1): '\' gives (dc,dr)=(0,1)? no.
            # '/' on down: (-dc,-dr)=(0,-1) -> left YES
            m2 = "/"
        else:
            # moving down (1,0) -> want right (0,1): '\' gives (dc,dr)=(0,1) YES
            m2 = "\\"
        if g[nr][end_c] != ".":
            break
        g[nr][end_c] = m2
        placed.append((nr, end_c))
        # resume horizontal opposite dir on row nr
        going_right = not going_right
        r = nr
        c = end_c + (1 if going_right else -1)
        ri += 1
    return src, placed, cats


def plant_pocket_cats(g, H, W, rng, n_pockets):
    """Carve walled 'pockets' and place a cat inside, reachable only via a
    detour (>=2 mirrors). We plant the detour beam from an existing-ish laser
    region. To keep it simple and feasible, we build each pocket + its own
    short laser with a 2-mirror dog-leg into the pocket mouth.

    Returns (srcs, placed_mirrors, cats).
    """
    srcs = []
    placed = []
    cats = []
    attempts = 0
    while len(cats) < n_pockets and attempts < n_pockets * 6:
        attempts += 1
        # pocket interior cell
        pr = rng.randint(3, H - 4)
        pc = rng.randint(3, W - 4)
        # build a small wall box around (pr,pc) with one open mouth
        box = [(pr - 1, pc - 1), (pr - 1, pc), (pr - 1, pc + 1),
               (pr, pc - 1), (pr, pc + 1),
               (pr + 1, pc - 1), (pr + 1, pc), (pr + 1, pc + 1)]
        # mouth: open one side (say top center)
        mouth = (pr - 1, pc)
        ok = all(in_b(H, W, r, c) for (r, c) in box)
        if not ok or g[pr][pc] != ".":
            continue
        # don't overwrite lasers/mirrors already placed
        if any(g[r][c] in "AV<>/\\O" for (r, c) in box):
            continue
        for (r, c) in box:
            if (r, c) != mouth:
                g[r][c] = "#"
        g[mouth[0]][mouth[1]] = "."  # keep open
        # Now plant a beam that does a dog-leg to enter through mouth going down.
        # We want beam to arrive at mouth moving down (V) so it reaches cat.
        # Place laser to the left moving right '>', a mirror above mouth turning down.
        # mirror cell = (pr-2, pc) must be free, laser on row pr-2 to its left.
        m1r, m1c = pr - 2, pc
        if not in_b(H, W, m1r, m1c) or g[m1r][m1c] != ".":
            continue
        # laser cell on same row, a few cells left
        lc = m1c - rng.randint(2, 5)
        if lc < 0 or g[m1r][lc] != ".":
            continue
        # the straight between laser and mirror must be clear
        seg_clear = all(g[m1r][cc] == "." for cc in range(lc + 1, m1c))
        if not seg_clear:
            continue
        # second mirror not needed if single dog-leg, but to force detour we add
        # a vertical wall segment forcing the beam to come from above only.
        # place laser
        g[m1r][lc] = ">"
        srcs.append((m1r, lc, ">"))
        # mirror '\' turns (0,1) -> (1,0) i.e. right->down  (refl '\': (dr,dc)->(dc,dr))
        g[m1r][m1c] = "\\"
        placed.append((m1r, m1c))
        # beam now goes down: (pr-2,pc)->(pr-1,pc=mouth)->(pr,pc=cat)
        g[pr][pc] = "O"
        cats.append((pr, pc))
    return srcs, placed, cats


def emit(g, H, W, L):
    return "\n".join([f"{W} {H} {L}"] + ["".join(x) for x in g]) + "\n"


def base_terrain(strat, H, W, rng):
    if strat == "pockets":
        # light scattering of walls; pockets added later
        dens = rng.uniform(0.10, 0.30)
        return [["#" if rng.random() < dens else "." for _ in range(W)] for _ in range(H)]
    if strat == "mixed":
        dens = rng.uniform(0.10, 0.35)
        return [["#" if rng.random() < dens else "." for _ in range(W)] for _ in range(H)]
    # serpentine: mostly open with occasional walls to force turning
    dens = rng.uniform(0.02, 0.12)
    return [["#" if rng.random() < dens else "." for _ in range(W)] for _ in range(H)]


def gen(seed, strat, H, W, slack):
    rng = random.Random(seed)
    g = base_terrain(strat, H, W, rng)
    srcs = []
    placed = []

    if strat == "boustro":
        # dense full-board single-laser serpentine; very many cats, few mirrors
        row_step = 2  # sweep every other row -> max cat count
        cat_fill = rng.uniform(0.92, 1.0)  # pack legs densely
        res = plant_boustrophedon(g, H, W, rng, row_step=row_step,
                                  cat_fill=cat_fill, margin=1)
        if not res:
            return None
        s, pl, _cats = res
        srcs.append(s)
        placed.extend(pl)
    elif strat == "serpentine":
        n_turns = rng.randint(4, 10)
        cats_per_leg = rng.randint(2, 5)
        res = plant_serpentine(g, H, W, rng, n_turns, cats_per_leg)
        if not res:
            return None
        s, pl, _cats = res
        srcs.append(s)
        placed.extend(pl)
    elif strat == "pockets":
        n_pockets = rng.randint(4, 12)
        s2, pl2, _c2 = plant_pocket_cats(g, H, W, rng, n_pockets)
        srcs.extend(s2)
        placed.extend(pl2)
        # also add one serpentine to bump cat count & sharing
        res = plant_serpentine(g, H, W, rng, rng.randint(2, 5), rng.randint(2, 4))
        if res:
            s, pl, _cats = res
            srcs.append(s)
            placed.extend(pl)
    else:  # mixed
        nser = rng.randint(2, 5)
        for _ in range(nser):
            res = plant_serpentine(g, H, W, rng, rng.randint(3, 7), rng.randint(2, 4))
            if res:
                s, pl, _cats = res
                srcs.append(s)
                placed.extend(pl)
        s2, pl2, _c2 = plant_pocket_cats(g, H, W, rng, rng.randint(2, 6))
        srcs.extend(s2)
        placed.extend(pl2)

    if not srcs or not placed:
        return None

    # Simulate to keep only genuinely-lit cats (full judge sim with mirrors in).
    lit = lit_cats(g, H, W, srcs)
    for r in range(H):
        for c in range(W):
            if g[r][c] == "O" and (r, c) not in lit:
                g[r][c] = "."
    ncats = sum(row.count("O") for row in g)
    if ncats < 3:
        return None

    # tight budget = exactly the planted mirrors (count distinct mirror cells)
    mcells = set(placed)
    # count actual mirrors currently on board (some 'placed' may have been freed)
    nm = sum(1 for (r, c) in mcells if g[r][c] in "/\\")
    if nm < 1:
        return None
    L = nm + slack
    # capture the planted mirror layout BEFORE erasing (for feasibility proof)
    mirror_layout = [(r, c, g[r][c]) for (r, c) in mcells if g[r][c] in "/\\"]
    # erase mirrors -> board becomes the puzzle instance
    for (r, c) in mcells:
        if g[r][c] in "/\\":
            g[r][c] = "."

    # FEASIBILITY PROOF: reinstall planted mirrors on the erased board and
    # confirm every retained cat is lit, using exactly len(mirror_layout)<=L
    # mirrors, each on a '.' cell of the puzzle instance.
    puzzle = [row[:] for row in g]
    cat_set = {(r, c) for r in range(H) for c in range(W) if g[r][c] == "O"}
    for (r, c, mt) in mirror_layout:
        if puzzle[r][c] != ".":
            return None  # would not be a legal placement
        puzzle[r][c] = mt
    relit = lit_cats(puzzle, H, W, srcs)
    if not cat_set.issubset(relit):
        return None  # not provably feasible -> drop it
    if len(mirror_layout) > L:
        return None

    return emit(g, H, W, L), len(cat_set), len(srcs), nm


# ----------------------------------------------------------------------------
# Validation of solver output: mirrors only on '.', count <= L, board matches.
# Returns (status, lit, tot, used).
# ----------------------------------------------------------------------------
DZ = {"A": (0, -1), "V": (0, 1), "<": (-1, 0), ">": (1, 0)}


def trace(b, x, y, dx, dy, bnd):
    H, W = len(b), len(b[0])
    s = 0
    while 0 <= y < H and 0 <= x < W:
        ch = b[y][x]
        if ch == "O":
            b[y][x] = "X"
        elif ch == "#":
            break
        elif ch == "/":
            dx, dy = -dy, -dx
        elif ch == "\\":
            dx, dy = dy, dx
        x += dx
        y += dy
        s += 1
        if s > bnd:
            return


def parse(txt):
    lines = txt.split("\n")
    W, H, M = map(int, lines[0].split())
    g = [list(lines[1 + i]) for i in range(H)]
    return W, H, M, g


def check(inp, out):
    W, H, M, ib = parse(inp)
    try:
        _, _, _, ob = parse(out)
    except Exception:
        return ("PARSEERR", 0, 0, 0)
    if len(ob) != H or any(len(r) != W for r in ob):
        return ("SHAPE", 0, 0, 0)
    used = 0
    for y in range(H):
        for x in range(W):
            if ob[y][x] in "/\\":
                used += 1
                if ib[y][x] != ".":
                    return ("BADPLACE", 0, 0, used)
            elif ob[y][x] != ib[y][x]:
                return ("MISMATCH", 0, 0, used)
    if used > M:
        return ("TOOMANY", 0, 0, used)
    tot = sum(r.count("O") for r in ib)
    B = W * H * 2
    for y in range(H):
        for x in range(W):
            if ob[y][x] in DZ:
                dx, dy = DZ[ob[y][x]]
                trace(ob, x, y, dx, dy, B)
    lit = tot - sum(r.count("O") for r in ob)
    return ("OK" if lit == tot else "PARTIAL", lit, tot, used)


def run_solver(inp, tlimit):
    try:
        r = subprocess.run([REF], input=inp, capture_output=True, text=True,
                           timeout=tlimit)
        return r.stdout
    except subprocess.TimeoutExpired:
        return None
    except Exception:
        return None


def hunt(nseeds, time_budget):
    os.makedirs(HUNT_DIR, exist_ok=True)
    # weight boustro heavily; it is the strongest breaker (overloads beam search)
    strats = ["boustro", "boustro", "boustro", "serpentine", "mixed", "pockets"]
    sizes = [(100, 100), (90, 90), (80, 80), (100, 80), (70, 100),
             (60, 60), (50, 80), (100, 60), (40, 40), (30, 30)]
    saved = []
    covs = []  # all feasible coverages
    t0 = time.time()
    seed = 1000
    tried = 0
    while tried < nseeds and (time.time() - t0) < time_budget:
        seed += 1
        tried += 1
        strat = strats[seed % len(strats)]
        H, W = sizes[seed % len(sizes)]
        slack = 0 if (seed % 4) else 1  # mostly tight, occasionally +1
        res = gen(seed, strat, H, W, slack)
        if not res:
            continue
        inp, ncats, nlasers, nm = res
        out = run_solver(inp, 12)
        if out is None:
            # timeout: solver couldn't solve in time -> very hard. Coverage 0 effectively.
            # Save as a breaker (it failed to produce any covering solution in time).
            fn = os.path.join(HUNT_DIR, f"tight_{seed}.in")
            with open(fn, "w") as f:
                f.write(inp)
            saved.append((os.path.basename(fn), W, H, nm + slack, ncats, nlasers, 0.0, "TIMEOUT"))
            covs.append(0.0)
            continue
        st, lit, tot, used = check(inp, out)
        if tot == 0:
            continue
        cov = lit / tot
        covs.append(cov)
        if cov < 0.5:
            fn = os.path.join(HUNT_DIR, f"tight_{seed}.in")
            with open(fn, "w") as f:
                f.write(inp)
            saved.append((os.path.basename(fn), W, H, nm + slack, ncats, nlasers, round(cov, 3), st))
    return saved, covs, tried, time.time() - t0


if __name__ == "__main__":
    if len(sys.argv) >= 6 and sys.argv[1] == "--one":
        seed = int(sys.argv[2])
        strat = sys.argv[3]
        H = int(sys.argv[4])
        W = int(sys.argv[5])
        slack = int(sys.argv[6]) if len(sys.argv) > 6 else 0
        res = gen(seed, strat, H, W, slack)
        if res:
            sys.stdout.write(res[0])
    elif len(sys.argv) >= 2 and sys.argv[1] == "run":
        nseeds = int(sys.argv[2]) if len(sys.argv) > 2 else 400
        tb = float(sys.argv[3]) if len(sys.argv) > 3 else 240.0
        saved, covs, tried, el = hunt(nseeds, tb)
        covs_sorted = sorted(covs)
        print(f"tried={tried} feasible_eval={len(covs)} elapsed={el:.1f}s saved={len(saved)}")
        if covs_sorted:
            n = len(covs_sorted)
            med = covs_sorted[n // 2]
            print(f"coverage min={covs_sorted[0]:.3f} median={med:.3f} max={covs_sorted[-1]:.3f}")
        print("SAVED breakers (cov<0.5):")
        for row in saved:
            nm, W, H, L, cats, las, cov, st = row
            print(f"  {nm}: {W} {H} {L} cats={cats} lasers={las} cov={cov} {st} "
                  f"L/cats={L/cats:.2f}")
    else:
        print(__doc__)
