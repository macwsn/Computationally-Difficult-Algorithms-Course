#!/usr/bin/env python3
"""Liczy oswietlone koty w wyjsciu (raytrace zgodny z judge). Uzycie: litcheck.py in.txt out.txt"""
import sys

DZ = {"A": (0, -1), "V": (0, 1), "<": (-1, 0), ">": (1, 0)}


def trace(b, x, y, dx, dy, bnd):
    H, W = len(b), len(b[0])
    s = 0
    while 0 <= y < H and 0 <= x < W:
        ch = b[y][x]
        if ch == "O":
            b[y][x] = "X"
        if ch == "#":
            break
        if ch == "/":
            dx, dy = -dy, -dx
        if ch == "\\":
            dx, dy = dy, dx
        x += dx; y += dy; s += 1
        if s > bnd:
            return


def load(fn):
    f = open(fn)
    W, H, M = map(int, f.readline().split())
    return [list(f.readline().rstrip("\n")) for _ in range(H)]


ib = load(sys.argv[1]); ob = load(sys.argv[2])
H, W = len(ob), len(ob[0]); B = W * H * 2
tot = sum(r.count("O") for r in ib)
for y in range(H):
    for x in range(W):
        if ob[y][x] in DZ:
            trace(ob, x, y, DZ[ob[y][x]][0], DZ[ob[y][x]][1], B)
lit = tot - sum(r.count("O") for r in ob)
print(f"{lit}/{tot}", "SOLVED" if lit == tot else "partial")
